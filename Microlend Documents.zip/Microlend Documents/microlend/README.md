# MicroLend — Phase 1 Complete Package

## Folder Structure

```
microlend/
├── backend/                             ← Spring Boot 3.2 Maven project
│   ├── pom.xml
│   └── src/
│       ├── main/java/com/microlend/
│       │   ├── MicroLendApplication.java        @EnableScheduling
│       │   ├── config/
│       │   │   ├── SecurityConfig.java           Bug Fix #1 #2 #3 + Swagger paths
│       │   │   ├── SwaggerConfig.java            OpenAPI 3.0 JWT
│       │   │   └── DataSeeder.java
│       │   ├── controller/                       17 controllers
│       │   ├── service/                          16 services
│       │   ├── scheduler/
│       │   │   └── DelinquencyScheduler.java     Bug Fix #5 nightly cron
│       │   ├── entity/                           17 JPA entities
│       │   ├── enums/                            24 enums
│       │   ├── repository/                       17 repositories
│       │   └── security/                         JWT
│       ├── main/resources/
│       │   └── application.properties            PORT 8082  MySQL  Swagger
│       └── test/java/com/microlend/
│           └── service/                          11 test files  102 tests
│
└── testing-tools/
    └── microlend_autorunner.html         Open in Chrome → Run Full Workflow
```

## Bug Fixes
| # | Fix |
|---|-----|
| 1 | /api/auth/register now requires ADMIN or BRANCH_MANAGER JWT — no anonymous access |
| 2 | Branch Manager scope enforced — cannot register ADMIN or users in other branches |
| 3 | FIELD_OFFICER blocked from PATCH /api/kyc/{id}/verify — 403 Forbidden |
| 4 | Partial payment marks installment PARTIAL (not stuck as PENDING), amountPaid cumulative |
| 5 | Nightly delinquency engine via @Scheduled cron, manual trigger endpoint added |

## Quick Start

```bash
# Ensure MySQL is running, then:
cd backend
mvn clean install -DskipTests
mvn spring-boot:run
```

- Server: http://localhost:8082
- Swagger UI: http://localhost:8082/swagger-ui.html
- Auto Workflow: open testing-tools/microlend_autorunner.html in Chrome

## Run Tests
```bash
cd backend
mvn test
# 102 tests, no DB needed (Mockito only)
```

## Default Credentials (seeded on startup)
| Role | Email | Password |
|------|-------|----------|
| ADMIN | admin@microlend.com | admin123 |
| BRANCH_MANAGER | anita.singh@microlend.com | Branch@123 |
| CREDIT_OFFICER | priya.sharma@microlend.com | Credit@123 |
| FIELD_OFFICER | ravi.kumar@microlend.com | Field@123 |
| COLLECTIONS_OFFICER | suresh.reddy@microlend.com | Collect@123 |
| BORROWER | lakshmi.devi@microlend.com | Borrower@123 |
