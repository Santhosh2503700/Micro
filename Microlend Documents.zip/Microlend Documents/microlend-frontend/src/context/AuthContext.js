import React, { createContext, useContext, useState } from 'react';
import { login as apiLogin } from '../api';

const AuthContext = createContext(null);

const ROLE_HOME = {
  ADMIN: '/admin',
  BRANCH_MANAGER: '/branch',
  CREDIT_OFFICER: '/credit',
  FIELD_OFFICER: '/field',
  COLLECTIONS_OFFICER: '/collections',
  BORROWER: '/borrower',
};

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem('ml_user')); } catch { return null; }
  });

  async function login(creds) {
    const r = await apiLogin(creds);
    const data = r.data.data;
    localStorage.setItem('ml_token', data.token);
    localStorage.setItem('ml_user', JSON.stringify(data));
    setUser(data);
    return { ok: true, to: ROLE_HOME[data.role] || '/' };
  }

  function logout() {
    localStorage.clear();
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, login, logout, ROLE_HOME }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
