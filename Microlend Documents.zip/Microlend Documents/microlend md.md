# MicroLend — Backend Technical Documentation

**NBFC Microfinance Loan Management System · Phase 1**

> Spring Boot 3.2 · Java 17 · MySQL 8 · JWT · SpringDoc OpenAPI 2.3 · Port 8082

---

## Table of Contents

1. [Project Overview](#1-project-overview)
2. [Technology Stack](#2-technology-stack)
3. [System Architecture](#3-system-architecture)
4. [Project Structure](#4-project-structure)
5. [Configuration Layer](#5-configuration-layer)
   - 5.1 [MicroLendApplication](#51-microlendapplication)
   - 5.2 [SecurityConfig](#52-securityconfig)
   - 5.3 [WebConfig](#53-webconfig)
   - 5.4 [SwaggerConfig](#54-swaggerconfig)
   - 5.5 [DataSeeder](#55-dataseeder)
   - 5.6 [application.properties](#56-applicationproperties)
6. [Security Layer](#6-security-layer)
   - 6.1 [JwtUtil](#61-jwtutil)
   - 6.2 [JwtAuthFilter](#62-jwtauthfilter)
   - 6.3 [CustomUserDetailsService](#63-customuserdetailsservice)
7. [Exception Handling](#7-exception-handling)
8. [Data Transfer Objects](#8-data-transfer-objects)
   - 8.1 [Response DTOs](#81-response-dtos)
   - 8.2 [Request DTOs](#82-request-dtos)
9. [Domain Enumerations](#9-domain-enumerations)
10. [Data Model — Entities](#10-data-model--entities)
    - 10.1 [User](#101-user)
    - 10.2 [AuditLog](#102-auditlog)
    - 10.3 [Borrower](#103-borrower)
    - 10.4 [BorrowerKYC](#104-borrowerkyc)
    - 10.5 [BorrowerGroup](#105-borrowergroup)
    - 10.6 [Centre](#106-centre)
    - 10.7 [CentreMeeting](#107-centremeeting)
    - 10.8 [LoanProduct](#108-loanproduct)
    - 10.9 [LoanApplication](#109-loanapplication)
    - 10.10 [CreditAssessment](#1010-creditassessment)
    - 10.11 [SanctionLetter](#1011-sanctionletter)
    - 10.12 [LoanAccount](#1012-loanaccount)
    - 10.13 [RepaymentSchedule](#1013-repaymentschedule)
    - 10.14 [CollectionRecord](#1014-collectionrecord)
    - 10.15 [DelinquencyCase](#1015-delinquencycase)
    - 10.16 [PortfolioReport](#1016-portfolioreport)
    - 10.17 [Notification](#1017-notification)
11. [Repository Layer](#11-repository-layer)
12. [Service Interfaces](#12-service-interfaces)
13. [Service Implementations](#13-service-implementations)
    - 13.1 [AuthServiceImpl](#131-authserviceimpl)
    - 13.2 [UserServiceImpl](#132-userserviceimpl)
    - 13.3 [AuditLogServiceImpl](#133-auditlogserviceimpl)
    - 13.4 [BorrowerServiceImpl](#134-borrowerserviceimpl)
    - 13.5 [BorrowerKYCServiceImpl](#135-borrowerkycserviceimpl)
    - 13.6 [BorrowerGroupServiceImpl](#136-borrowergroupserviceimpl)
    - 13.7 [CentreServiceImpl](#137-centreserviceimpl)
    - 13.8 [CentreMeetingServiceImpl](#138-centremeetingserviceimpl)
    - 13.9 [LoanProductServiceImpl](#139-loanproductserviceimpl)
    - 13.10 [LoanApplicationServiceImpl](#1310-loanapplicationserviceimpl)
    - 13.11 [CreditAssessmentServiceImpl](#1311-creditassessmentserviceimpl)
    - 13.12 [SanctionLetterServiceImpl](#1312-sanctionletterserviceimpl)
    - 13.13 [LoanDisbursementServiceImpl](#1313-loandisbursementserviceimpl)
    - 13.14 [CollectionServiceImpl](#1314-collectionserviceimpl)
    - 13.15 [DelinquencyServiceImpl](#1315-delinquencyserviceimpl)
    - 13.16 [PortfolioReportServiceImpl](#1316-portfolioreportserviceimpl)
    - 13.17 [NotificationServiceImpl](#1317-notificationserviceimpl)
14. [Controller Layer — REST API](#14-controller-layer--rest-api)
    - 14.1 [AuthController](#141-authcontroller)
    - 14.2 [UserController](#142-usercontroller)
    - 14.3 [AuditLogController](#143-auditlogcontroller)
    - 14.4 [BorrowerController](#144-borrowercontroller)
    - 14.5 [KYCController](#145-kyccontroller)
    - 14.6 [BorrowerGroupController](#146-borrowergroupcontroller)
    - 14.7 [CentreController](#147-centrecontroller)
    - 14.8 [CentreMeetingController](#148-centremeetingcontroller)
    - 14.9 [LoanProductController](#149-loanproductcontroller)
    - 14.10 [LoanApplicationController](#1410-loanapplicationcontroller)
    - 14.11 [CreditAssessmentController](#1411-creditassessmentcontroller)
    - 14.12 [SanctionLetterController](#1412-sanctionlettercontroller)
    - 14.13 [LoanAccountController](#1413-loanaccountcontroller)
    - 14.14 [CollectionController](#1414-collectioncontroller)
    - 14.15 [DelinquencyController](#1415-delinquencycontroller)
    - 14.16 [PortfolioReportController](#1416-portfolioreportcontroller)
    - 14.17 [NotificationController](#1417-notificationcontroller)
15. [Automated Delinquency Scheduler](#15-automated-delinquency-scheduler)
16. [Complete API Reference](#16-complete-api-reference)
17. [Role-Based Access Control Matrix](#17-role-based-access-control-matrix)
18. [Loan Application State Machine](#18-loan-application-state-machine)
19. [EMI Calculation Formulas](#19-emi-calculation-formulas)
20. [Collection Payment State Machine](#20-collection-payment-state-machine)
21. [Default Credentials & Data Seeding](#21-default-credentials--data-seeding)
22. [Test Coverage](#22-test-coverage)
23. [Quick Start Guide](#23-quick-start-guide)

---

## 1. Project Overview

MicroLend is an enterprise-grade REST API backend for **NBFC (Non-Banking Financial Company) microfinance operations**. It manages the complete lifecycle of micro-loans — from borrower registration and KYC verification through credit assessment, loan disbursement with EMI schedule generation, weekly EMI collection, automated nightly delinquency detection, and portfolio reporting.

The system enforces strict **Role-Based Access Control (RBAC)** across six distinct user roles. Every API endpoint is protected by dual-layer security: route-level rules in `SecurityConfig` and method-level `@PreAuthorize` annotations on each controller method.

### System Roles

| Role | Primary Responsibilities |
|------|--------------------------|
| `ADMIN` | Full system access — loan products, staff provisioning, audit logs, reports, system management |
| `BRANCH_MANAGER` | Portfolio oversight, delinquency management, staff provisioning within own branch, notifications |
| `CREDIT_OFFICER` | KYC verification (maker-checker), credit scoring, application approval, sanction issuance, disbursement |
| `FIELD_OFFICER` | Borrower registration, KYC document upload, centre and group management, loan applications, meetings, EMI collection |
| `COLLECTIONS_OFFICER` | Delinquency case management, recovery action tracking |
| `BORROWER` | Self-service portal — view own loans, repayment schedule, and notifications |

### Key Metrics

| Metric | Value |
|--------|-------|
| Java source files | 139 |
| REST endpoints | 80 |
| Controllers | 17 |
| Service interfaces | 17 |
| Service implementations | 17 |
| JPA entities | 17 |
| MySQL tables | 17 |
| Enumerations | 25 |
| Test classes | 12 |
| Server port | 8082 |
| Base package | `com.microlend` |

---

## 2. Technology Stack

| Component | Technology | Version |
|-----------|-----------|---------|
| Framework | Spring Boot | 3.2.0 |
| Language | Java | 17 LTS |
| Build tool | Maven | `spring-boot-starter-parent 3.2.0` |
| Database | MySQL | 8.0 |
| Test database | H2 | In-memory (test scope) |
| ORM | Spring Data JPA / Hibernate | MySQL8Dialect |
| Security | Spring Security | 6.x |
| JWT library | jjwt | 0.11.5 (api + impl + jackson) |
| API documentation | SpringDoc OpenAPI | 2.3.0 |
| Code generation | Lombok | Latest |
| Bean validation | Jakarta Validation | `spring-boot-starter-validation` |
| Task scheduling | Spring `@Scheduled` | Pool size: 5 |
| CORS | Spring `WebMvcConfigurer` | `WebConfig.java` |

### Maven Dependencies

```xml
spring-boot-starter-web
spring-boot-starter-data-jpa
spring-boot-starter-security
spring-boot-starter-validation
jjwt-api / jjwt-impl / jjwt-jackson   (0.11.5)
mysql-connector-j                       (runtime)
h2                                      (runtime, test DB)
lombok                                  (optional)
springdoc-openapi-starter-webmvc-ui    (2.3.0)
spring-boot-starter-test
spring-security-test
```

---

## 3. System Architecture

MicroLend follows the standard **Spring MVC layered architecture** with a clean **Service Interface + Implementation** separation pattern:

```
┌─────────────────────────────────────────────────────────────────┐
│  HTTP Request                                                   │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│  JwtAuthFilter  (OncePerRequestFilter)                          │
│  — Extracts Bearer token from Authorization header              │
│  — Validates signature and expiry via JwtUtil                   │
│  — Sets UsernamePasswordAuthenticationToken in SecurityContext   │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│  SecurityConfig  (Route-level authorization rules)              │
│  — Stateless session policy                                     │
│  — CSRF disabled                                                │
│  — Per-path role requirements                                   │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│  @RestController  (17 controllers)                              │
│  — HTTP method routing and path mapping                         │
│  — @Valid request body validation                               │
│  — @PreAuthorize method-level RBAC (defence-in-depth)           │
│  — Returns ResponseEntity<ApiResponse<T>>                       │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│  Service Interface  (17 interfaces in service/)                 │
│  — Pure Java interfaces — no implementation code                │
│  — Controllers depend on abstractions, not concrete classes     │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│  @Service Implementation  (17 classes in service/impl/)         │
│  — All business logic lives here                                │
│  — @Transactional on multi-write operations                     │
│  — Throws BadRequestException / ResourceNotFoundException       │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│  @Repository  (17 JpaRepository extensions)                     │
│  — Custom JPQL @Query annotations                               │
│  — Domain-specific finder methods                               │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│  @Entity  (17 JPA entities → 17 MySQL tables)                   │
│  — @GeneratedValue(strategy = IDENTITY) — AUTO_INCREMENT        │
│  — @Enumerated(EnumType.STRING) — human-readable in DB          │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
                MySQL 8  (jdbc:mysql://localhost:3306/microlend)
```

**Cross-cutting concerns:**

- `GlobalExceptionHandler` — `@RestControllerAdvice` that intercepts all exceptions and returns consistent JSON error envelopes.
- `ApiResponse<T>` — generic success wrapper used by all 80 endpoints.
- `AuditLog` — immutable event store; the nightly scheduler writes entries with `userID = 0` to distinguish automated events from user actions.
- `DelinquencyScheduler` — independent `@Scheduled` cron running at `00:30 AM` every day. Operates outside any HTTP request context.

---

## 4. Project Structure

```
microlend/backend/
├── pom.xml
└── src/
    ├── main/
    │   ├── resources/
    │   │   └── application.properties
    │   └── java/com/microlend/
    │       ├── MicroLendApplication.java          Entry point · @SpringBootApplication · @EnableScheduling
    │       ├── config/
    │       │   ├── DataSeeder.java                CommandLineRunner — seeds Admin on startup
    │       │   ├── SecurityConfig.java            JWT filter chain · route-level RBAC
    │       │   ├── SwaggerConfig.java             OpenAPI 3 · JWT bearer auth scheme
    │       │   └── WebConfig.java                 Global CORS configuration
    │       ├── security/
    │       │   ├── JwtUtil.java                   HS256 token generation and validation
    │       │   ├── JwtAuthFilter.java             OncePerRequestFilter · Bearer extraction
    │       │   └── CustomUserDetailsService.java  loadUserByUsername(email)
    │       ├── exception/
    │       │   ├── GlobalExceptionHandler.java    @RestControllerAdvice · exception→HTTP mapping
    │       │   ├── BadRequestException.java       RuntimeException → HTTP 400
    │       │   └── ResourceNotFoundException.java RuntimeException → HTTP 404
    │       ├── dto/
    │       │   ├── request/  (15 DTO classes)
    │       │   └── response/ (ApiResponse.java · AuthResponse.java)
    │       ├── enums/         (25 enum files)
    │       ├── entity/        (17 entity files)
    │       ├── repository/    (17 repository interfaces)
    │       ├── service/       (17 service interfaces)
    │       │   └── impl/      (17 service implementation classes)
    │       ├── controller/    (17 controller classes)
    │       └── scheduler/
    │           └── DelinquencyScheduler.java      @Scheduled(cron="0 30 0 * * *")
    └── test/java/com/microlend/
        ├── MicroLendApplicationTests.java         Context load · H2 in-memory
        └── service/  (11 service test classes)
```

---

## 5. Configuration Layer

### 5.1 MicroLendApplication

The application entry point. `@SpringBootApplication` enables component scanning, auto-configuration, and `@Configuration` processing. `@EnableScheduling` activates Spring's task scheduling infrastructure, which is required for the `DelinquencyScheduler` cron job to fire.

```java
@SpringBootApplication
@EnableScheduling
public class MicroLendApplication {
    public static void main(String[] args) {
        SpringApplication.run(MicroLendApplication.class, args);
    }
}
```

---

### 5.2 SecurityConfig

Annotated `@Configuration @EnableWebSecurity @EnableMethodSecurity`. Defines the complete HTTP security filter chain.

**Design principles:**
- `SessionCreationPolicy.STATELESS` — no HTTP session is created. Every request is independently authenticated via its JWT.
- CSRF disabled — safe for a stateless REST API with no session cookies.
- `@EnableMethodSecurity` — enables `@PreAuthorize` on controller methods, providing defence-in-depth over route-level rules.
- `JwtAuthFilter` is inserted before `UsernamePasswordAuthenticationFilter`.

**Route-level authorization rules** (evaluated top-to-bottom, first match wins):

| Route Pattern | Method | Allowed Roles |
|--------------|--------|---------------|
| `/api/auth/login` | POST | PUBLIC |
| `/swagger-ui/**`, `/v3/api-docs/**` | GET | PUBLIC |
| `/h2-console/**` | ANY | PUBLIC |
| `/actuator/health` | GET | PUBLIC |
| `/api/auth/register` | POST | ADMIN, BRANCH_MANAGER |
| `/api/admin/**` | ANY | ADMIN |
| `/api/loan-products/**` | ANY | ADMIN, CREDIT_OFFICER |
| `/api/borrowers/**` | ANY | ADMIN, CREDIT_OFFICER, FIELD_OFFICER, BRANCH_MANAGER |
| `POST /api/kyc` | POST | ADMIN, CREDIT_OFFICER, FIELD_OFFICER |
| `PATCH /api/kyc/{id}/verify` | PATCH | ADMIN, CREDIT_OFFICER |
| `/api/kyc/**` | ANY | ADMIN, CREDIT_OFFICER, BRANCH_MANAGER |
| `/api/credit-assessments/**` | ANY | ADMIN, CREDIT_OFFICER |
| `/api/centres/**` | ANY | ADMIN, FIELD_OFFICER, BRANCH_MANAGER |
| `/api/groups/**` | ANY | ADMIN, FIELD_OFFICER, BRANCH_MANAGER |
| `/api/meetings/**` | ANY | ADMIN, FIELD_OFFICER, BRANCH_MANAGER |
| `/api/loan-applications/**` | ANY | ADMIN, CREDIT_OFFICER, BORROWER, BRANCH_MANAGER, FIELD_OFFICER |
| `/api/sanction-letters/**` | ANY | ADMIN, CREDIT_OFFICER, BORROWER |
| `/api/loan-accounts/**` | ANY | ADMIN, CREDIT_OFFICER, BORROWER, BRANCH_MANAGER, COLLECTIONS_OFFICER |
| `/api/collections/**` | ANY | ADMIN, FIELD_OFFICER, COLLECTIONS_OFFICER, BRANCH_MANAGER |
| `/api/delinquency/**` | ANY | ADMIN, COLLECTIONS_OFFICER, BRANCH_MANAGER |
| `/api/reports/**` | ANY | ADMIN, BRANCH_MANAGER |
| `/api/notifications/**` | ANY | Authenticated |

**Beans:** `SecurityFilterChain`, `AuthenticationProvider` (DaoAuthenticationProvider + BCrypt), `AuthenticationManager`, `PasswordEncoder` (BCryptPasswordEncoder).

---

### 5.3 WebConfig

Implements `WebMvcConfigurer` to provide global CORS configuration, enabling the React frontend running on port 3000 to communicate with the backend on port 8082.

```java
@Configuration
public class WebConfig implements WebMvcConfigurer {
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins("*")
                .allowedMethods("*")
                .allowedHeaders("*");
    }
}
```

The wildcard configuration is suitable for development environments. For production deployments, `allowedOrigins` should be restricted to the specific frontend domain.

---

### 5.4 SwaggerConfig

Configures SpringDoc OpenAPI 3 API documentation with a JWT bearer authentication scheme, making it possible to test all 80 endpoints directly from the Swagger UI after providing a login token.

**Settings:**
- Title: `MicroLend API` · Version: `1.0`
- Development server: `http://localhost:8082`
- Security scheme: `bearerAuth` — type `HTTP`, scheme `bearer`, format `JWT`
- Global `SecurityRequirement`: every endpoint shows the lock icon in Swagger UI

**Access:** `http://localhost:8082/swagger-ui.html`

The description field includes a visual HTML-formatted pipeline showing the complete loan lifecycle workflow from Admin Login through to Audit Logs.

---

### 5.5 DataSeeder

Implements `CommandLineRunner` — executes once at every application startup. Uses `userRepository.existsByEmail()` before inserting, making seeding idempotent across restarts.

**Seeded account:**

| Role | Email | Password | Branch |
|------|-------|----------|--------|
| ADMIN | `admin@microlend.com` | `admin123` | 1 |

All staff accounts (CREDIT_OFFICER, FIELD_OFFICER, BRANCH_MANAGER, COLLECTIONS_OFFICER) are created by the Admin via `POST /api/auth/register` after login. Borrower accounts are automatically created by the system when a borrower is registered via `POST /api/borrowers`.

All passwords are stored as BCrypt hashes — never in plain text.

---

### 5.6 application.properties

```properties
# ── Application ──────────────────────────────────────────────────────────────
spring.application.name=MicroLend
server.port=8082

# ── MySQL ─────────────────────────────────────────────────────────────────────
spring.datasource.url=jdbc:mysql://localhost:3306/microlend?createDatabaseIfNotExist=true&useSSL=false&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=root
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver

# ── JPA / Hibernate ───────────────────────────────────────────────────────────
spring.jpa.database-platform=org.hibernate.dialect.MySQL8Dialect
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.format_sql=true
spring.jpa.properties.hibernate.dialect.storage_engine=innodb
spring.jpa.properties.hibernate.jdbc.lob.non_contextual_creation=true

# ── JWT ───────────────────────────────────────────────────────────────────────
app.jwt.secret=MicroLendSuperSecretKeyForJWTTokenGenerationAndValidation2024SecureKey
app.jwt.expiration=86400000

# ── Scheduling ────────────────────────────────────────────────────────────────
spring.task.scheduling.pool.size=5

# ── Swagger ───────────────────────────────────────────────────────────────────
springdoc.swagger-ui.path=/swagger-ui.html
springdoc.api-docs.path=/v3/api-docs
springdoc.swagger-ui.operationsSorter=method
springdoc.swagger-ui.tryItOutEnabled=true
springdoc.swagger-ui.displayRequestDuration=true

# ── Logging ───────────────────────────────────────────────────────────────────
logging.level.com.microlend=DEBUG
logging.level.org.springframework.security=DEBUG
```

**Key notes:**
- `ddl-auto=update` — Hibernate auto-creates all 17 tables on first run and applies schema changes on subsequent runs. The `microlend` database is auto-created by the JDBC URL parameter `createDatabaseIfNotExist=true`.
- `app.jwt.expiration=86400000` — 24 hours in milliseconds.
- The JWT secret must be at least 256 bits (32 characters) for HS256. The provided secret is 64 characters.
- Change `spring.datasource.username` and `password` for non-development environments.

---

## 6. Security Layer

### 6.1 JwtUtil

Handles all JWT token operations using `jjwt 0.11.5`.

**Algorithm:** HS256 (HMAC-SHA256)  
**Signing key:** Derived from `app.jwt.secret` via `Keys.hmacShaKeyFor(secret.getBytes())`

| Method | Signature | Description |
|--------|-----------|-------------|
| `generateToken` | `(UserDetails) → String` | Creates a signed JWT with `sub=email`, `role=ROLE_XXX` claim, `iat=now`, `exp=now+expiration` |
| `validateToken` | `(String, UserDetails) → Boolean` | Returns true if the subject matches and token is not expired |
| `extractUsername` | `(String) → String` | Parses and returns the `sub` (email) claim |
| `extractClaim` | `(String, Function<Claims,T>) → T` | Generic claim extractor |
| `isTokenExpired` | `(String) → Boolean` | Returns true if `exp` is in the past |

**Token payload structure:**
```json
{
  "sub": "admin@microlend.com",
  "role": "ROLE_ADMIN",
  "iat": 1710000000,
  "exp": 1710086400
}
```

---

### 6.2 JwtAuthFilter

Extends `OncePerRequestFilter` — guaranteed to execute exactly once per HTTP request, regardless of filter chain configuration.

**Execution flow:**
1. Read `Authorization` header from the request.
2. If header starts with `"Bearer "`, extract the raw JWT string.
3. Call `jwtUtil.extractUsername(jwt)` to parse the subject claim. Parsing exceptions are caught silently and logged as warnings — the filter chain continues.
4. If a username was extracted and no authentication already exists in `SecurityContextHolder`:
   - Call `userDetailsService.loadUserByUsername(username)` to load the `User` entity from the database.
   - Call `jwtUtil.validateToken(jwt, userDetails)` to verify signature and expiry.
   - If valid: create `UsernamePasswordAuthenticationToken` with the user's `GrantedAuthority` list and set it in `SecurityContextHolder`.
5. Continue the filter chain unconditionally. Downstream `@PreAuthorize` annotations reject unauthorized requests.

---

### 6.3 CustomUserDetailsService

Implements Spring's `UserDetailsService`. Used by `DaoAuthenticationProvider` during credential verification at login time.

```java
@Override
public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
    return userRepository.findByEmail(email)
            .orElseThrow(() -> new UsernameNotFoundException("User not found with email: " + email));
}
```

The `User` entity itself implements `UserDetails`. Key method implementations:

| UserDetails method | Implementation |
|-------------------|----------------|
| `getUsername()` | Returns `email` |
| `getAuthorities()` | Returns `[ROLE_ + role.name()]` |
| `isAccountNonLocked()` | Returns `status != UserStatus.SUSPENDED` |
| `isEnabled()` | Returns `status == UserStatus.ACTIVE` |
| `isAccountNonExpired()` | Returns `true` |
| `isCredentialsNonExpired()` | Returns `true` |

When `isAccountNonLocked()` returns false (suspended user), Spring Security throws `LockedException`, which produces a 401 Unauthorized response.

---

## 7. Exception Handling

`GlobalExceptionHandler` (`@RestControllerAdvice`) intercepts all unhandled exceptions from any controller. Every error response has a consistent structure:

**Standard error response:**
```json
{
  "timestamp": "2024-03-15T10:30:00",
  "status": 403,
  "error": "Forbidden",
  "message": "Access denied: You don't have permission"
}
```

**Validation error response** (adds `details` map):
```json
{
  "timestamp": "2024-03-15T10:30:00",
  "status": 400,
  "error": "Validation Failed",
  "details": {
    "email": "must not be blank",
    "requestedAmount": "must not be null"
  }
}
```

**Exception-to-HTTP mapping:**

| Exception Class | HTTP Status | Scenario |
|----------------|-------------|---------|
| `ResourceNotFoundException` | 404 Not Found | Entity not found by ID |
| `BadRequestException` | 400 Bad Request | Business rule violation (dedup, invalid state, closed account) |
| `AccessDeniedException` | 403 Forbidden | `@PreAuthorize` role check fails |
| `BadCredentialsException` | 401 Unauthorized | Wrong email or password at login |
| `SecurityException` | 403 Forbidden | Branch Manager scope violation |
| `MethodArgumentNotValidException` | 400 Bad Request | `@Valid` DTO validation failure |
| `Exception` (catch-all) | 500 Internal Server Error | Unexpected runtime error |

---

## 8. Data Transfer Objects

### 8.1 Response DTOs

**`ApiResponse<T>`** — Generic response envelope used by all 80 endpoints:

```java
public class ApiResponse<T> {
    private boolean success;  // true for all 2xx responses
    private String message;   // human-readable description
    private T data;           // the actual payload (entity, list, or null)

    // Static factory methods:
    ApiResponse.success(data)
    ApiResponse.success(message, data)
    ApiResponse.error(message)
}
```

**`AuthResponse`** — Returned by both `/api/auth/login` and `/api/auth/register`:

| Field | Type | Description |
|-------|------|-------------|
| `token` | String | Signed JWT — include in `Authorization: Bearer <token>` header |
| `type` | String | Always `"Bearer"` |
| `userID` | Long | Database primary key of the user |
| `name` | String | User's display name |
| `email` | String | Login email address |
| `role` | UserRole | The user's system role |
| `branchID` | Long | Branch assignment (`null` for BORROWER role) |

---

### 8.2 Request DTOs

All request DTOs use Jakarta Validation annotations. Fields annotated `@NotBlank` or `@NotNull` are mandatory; all others are optional unless stated.

| DTO Class | Required Fields | Used By |
|-----------|----------------|---------|
| `LoginRequest` | `@Email @NotBlank email`, `@NotBlank password` | `POST /api/auth/login` |
| `RegisterUserRequest` | `@NotBlank name`, `@NotNull role`, `@Email email`, `@NotBlank password` | `POST /api/auth/register` |
| `BorrowerRequest` | `@NotBlank name`, `@Email @NotBlank email`, `@NotBlank password` | `POST /api/borrowers` |
| `BorrowerKYCRequest` | `@NotNull borrowerID`, `documentType`, `documentRef` | `POST /api/kyc` |
| `BorrowerGroupRequest` | `@NotBlank groupName` | `POST/PUT /api/groups` |
| `CentreRequest` | `@NotBlank centreName` | `POST/PUT /api/centres` |
| `CentreMeetingRequest` | `@NotNull centreID` | `POST/PUT /api/meetings` |
| `LoanProductRequest` | `@NotBlank productName`, `@NotNull interestRatePercent`, `@NotNull tenureMonths`, `@NotNull interestType` | `POST/PUT /api/loan-products` |
| `LoanApplicationRequest` | `@NotNull borrowerID`, `@NotNull loanProductID`, `@NotNull requestedAmount` | `POST /api/loan-applications` |
| `LoanApplicationStatusRequest` | `@NotNull status` | `PATCH /api/loan-applications/{id}/status` |
| `CreditAssessmentRequest` | `@NotNull borrowerID` | `POST/PUT /api/credit-assessments` |
| `SanctionLetterRequest` | `@NotNull applicationID`, `@NotNull sanctionedAmount`, `@NotNull interestRate`, `@NotNull tenure`, `@NotNull emiAmount` | `POST /api/sanction-letters` |
| `DisbursementRequest` | `@NotNull applicationID`, `@NotNull disbursedAmount` | `POST /api/loan-accounts/disburse` |
| `CollectionRequest` | `@NotNull loanAccountID`, `@NotNull collectedAmount`, `@NotNull mode` | `POST /api/collections` |
| `DelinquencyCaseRequest` | `@NotNull loanAccountID` | `POST/PUT /api/delinquency` |

---

## 9. Domain Enumerations

All 25 enumerations are persisted as `@Enumerated(EnumType.STRING)` — stored as their name string in MySQL columns, never as integer ordinals. This keeps the database human-readable and safe against enum re-ordering.

| Enum | Values |
|------|--------|
| `UserRole` | `BORROWER`, `FIELD_OFFICER`, `CREDIT_OFFICER`, `BRANCH_MANAGER`, `COLLECTIONS_OFFICER`, `ADMIN` |
| `UserStatus` | `ACTIVE`, `INACTIVE`, `SUSPENDED` |
| `BorrowerStatus` | `ACTIVE`, `BLACKLISTED`, `DECEASED` |
| `KYCStatus` | `PENDING`, `VERIFIED`, `REJECTED`, `EXPIRED` |
| `KYCDocumentType` | `NATIONAL_ID`, `VOTER_ID`, `PASSPORT`, `UTILITY_BILL` |
| `CentreStatus` | `ACTIVE`, `INACTIVE` |
| `GroupStatus` | `ACTIVE`, `DISSOLVED`, `SUSPENDED` |
| `MeetingDay` | `MONDAY`, `TUESDAY`, `WEDNESDAY`, `THURSDAY`, `FRIDAY`, `SATURDAY` |
| `MeetingStatus` | `SCHEDULED`, `CONDUCTED`, `MISSED`, `POSTPONED` |
| `LoanProductCategory` | `INDIVIDUAL`, `GROUP_LENDING`, `MSME`, `AGRICULTURAL` |
| `InterestType` | `FLAT`, `REDUCING` |
| `ProductStatus` | `ACTIVE`, `DISCONTINUED` |
| `ApplicationStatus` | `DRAFT`, `SUBMITTED`, `UNDER_REVIEW`, `APPROVED`, `REJECTED`, `DISBURSED` |
| `CreditRecommendation` | `ELIGIBLE`, `NOT_ELIGIBLE`, `CONDITIONAL` |
| `SanctionStatus` | `ISSUED`, `ACCEPTED`, `LAPSED` |
| `LoanAccountStatus` | `ACTIVE`, `CLOSED`, `NPA`, `WRITTEN_OFF` |
| `InstallmentStatus` | `PENDING`, `PARTIAL`, `PAID`, `OVERDUE`, `WAIVED` |
| `CollectionMode` | `CASH`, `BANK_TRANSFER`, `CENTRE_COLLECTION` |
| `CollectionStatus` | `RECEIVED`, `PARTIAL`, `EXCESS` |
| `DelinquencyAction` | `FIELD_VISIT`, `LEGAL_NOTICE`, `RESTRUCTURING`, `WRITE_OFF` |
| `DelinquencyStatus` | `OPEN`, `IN_PROGRESS`, `RESOLVED`, `WRITTEN_OFF` |
| `PARBucket` | `PAR30`, `PAR60`, `PAR90`, `PAR180` |
| `NotificationCategory` | `REPAYMENT`, `DISBURSEMENT`, `MEETING`, `DELINQUENCY`, `COMPLIANCE` |
| `NotificationStatus` | `UNREAD`, `READ`, `DISMISSED` |
| `ReportScope` | `BRANCH`, `PRODUCT`, `FIELD_OFFICER`, `PERIOD` |

---

## 10. Data Model — Entities

All entities share these JPA conventions:
- `@GeneratedValue(strategy = GenerationType.IDENTITY)` — MySQL `AUTO_INCREMENT` primary key
- `@Enumerated(EnumType.STRING)` — all enum columns stored as strings
- Lombok: `@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder`
- No `@ManyToOne` / `@OneToMany` JPA relationships (except `Borrower → User`) — cross-entity references are stored as plain `Long` foreign key fields to keep queries explicit and avoid N+1 problems

### 10.1 User

**Table:** `users` | **Implements:** `UserDetails` (Spring Security)

| Column | Type | Constraint | Description |
|--------|------|-----------|-------------|
| `userID` | Long | PK, AUTO | |
| `name` | String | NOT NULL | Display name |
| `role` | UserRole | NOT NULL | Determines `ROLE_XXX` authority |
| `email` | String | NOT NULL, UNIQUE | Used as the login username by `CustomUserDetailsService` |
| `password` | String | NOT NULL | BCrypt-encoded |
| `phone` | String | nullable | |
| `branchID` | Long | nullable | `null` for BORROWER role |
| `status` | UserStatus | default=ACTIVE | SUSPENDED blocks login via `isAccountNonLocked()=false` |

---

### 10.2 AuditLog

**Table:** `audit_logs` | **Immutable** — no update or delete endpoints exist

| Column | Type | Description |
|--------|------|-------------|
| `auditID` | Long | PK, AUTO |
| `userID` | Long | `0` = SYSTEM (written by `DelinquencyScheduler`) |
| `action` | String | e.g. `AUTO_CREATE_DELINQUENCY_CASE` |
| `module` | String | e.g. `DELINQUENCY` |
| `timestamp` | LocalDateTime | default = `LocalDateTime.now()` |

---

### 10.3 Borrower

**Table:** `borrowers`

| Column | Type | Constraint | Description |
|--------|------|-----------|-------------|
| `borrowerID` | Long | PK, AUTO | |
| `name` | String | NOT NULL | |
| `email` | String | UNIQUE | Borrower's own email — used as login username for the self-service portal |
| `dateOfBirth` | LocalDate | nullable | |
| `gender` | String | nullable | |
| `nationalIDNumber` | String | UNIQUE | Aadhaar or national ID — dedup check on registration |
| `village` | String | nullable | |
| `district` | String | nullable | |
| `phone` | String | nullable | |
| `occupation` | String | nullable | |
| `monthlyIncome` | BigDecimal | nullable | |
| `bankAccountNumber` | String | nullable | |
| `status` | BorrowerStatus | default=ACTIVE | |
| `user` | User | `@OneToOne @JoinColumn(user_id)` | Linked `User` account — auto-created on borrower registration |

**Borrower–User relationship:** When a borrower is registered, `BorrowerServiceImpl.create()` first creates a `User` record with `role=BORROWER` using the provided email and password, then links it to the new `Borrower` record via the `@OneToOne` relationship. This allows the borrower to log in and access their portal. Deleting a borrower cascades to delete the linked `User` account.

---

### 10.4 BorrowerKYC

**Table:** `borrower_kyc`

| Column | Type | Description |
|--------|------|-------------|
| `kycID` | Long | PK, AUTO |
| `borrowerID` | Long | FK → Borrower |
| `documentType` | KYCDocumentType | NATIONAL_ID / VOTER_ID / PASSPORT / UTILITY_BILL |
| `documentRef` | String | Filename or storage path of the scanned document |
| `verifiedByID` | Long | FK → User (Credit Officer who verified / rejected) |
| `verificationDate` | LocalDate | Set when verification action is taken |
| `status` | KYCStatus | default=PENDING |

---

### 10.5 BorrowerGroup

**Table:** `borrower_groups`

Joint Liability Groups (JLG) — members of the group co-guarantee each other's loans when `jointLiabilityEnabled = true`.

| Column | Type | Description |
|--------|------|-------------|
| `groupID` | Long | PK, AUTO |
| `groupName` | String | NOT NULL |
| `centreID` | Long | FK → Centre |
| `fieldOfficerID` | Long | FK → User |
| `formationDate` | LocalDate | Defaults to `LocalDate.now()` if not provided |
| `memberCount` | Integer | default=0 |
| `jointLiabilityEnabled` | Boolean | default=false |
| `status` | GroupStatus | default=ACTIVE |

---

### 10.6 Centre

**Table:** `centres`

Geographic unit for field operations. A centre holds weekly group meetings and belongs to a branch.

| Column | Type | Description |
|--------|------|-------------|
| `centreID` | Long | PK, AUTO |
| `centreName` | String | NOT NULL |
| `branchID` | Long | Owning branch ID |
| `fieldOfficerID` | Long | FK → User (assigned Field Officer) |
| `village` | String | Village location |
| `meetingDay` | MeetingDay | Day of the week for recurring meetings |
| `meetingTime` | LocalTime | Time of the recurring meeting |
| `status` | CentreStatus | default=ACTIVE |

---

### 10.7 CentreMeeting

**Table:** `centre_meetings`

Records the outcome of each weekly field meeting — attendance count and total EMI collected.

| Column | Type | Description |
|--------|------|-------------|
| `meetingID` | Long | PK, AUTO |
| `centreID` | Long | NOT NULL — FK → Centre |
| `meetingDate` | LocalDate | Defaults to `LocalDate.now()` |
| `conductedByID` | Long | FK → User (Field Officer who conducted) |
| `attendanceCount` | Integer | default=0 |
| `collectionAmount` | BigDecimal | default=ZERO — total EMI collected at this meeting |
| `status` | MeetingStatus | default=SCHEDULED |

---

### 10.8 LoanProduct

**Table:** `loan_products`

Defines the lending catalogue. Used by `LoanDisbursementServiceImpl` to determine EMI calculation parameters.

| Column | Type | Description |
|--------|------|-------------|
| `productID` | Long | PK, AUTO |
| `productName` | String | NOT NULL |
| `category` | LoanProductCategory | GROUP_LENDING / INDIVIDUAL / MSME / AGRICULTURAL |
| `minAmount` | BigDecimal | Minimum eligible loan amount |
| `maxAmount` | BigDecimal | Maximum eligible loan amount |
| `tenureMonths` | Integer | Loan tenor in months |
| `interestRatePercent` | BigDecimal | Annual interest rate (%) |
| `interestType` | InterestType | `FLAT` or `REDUCING` — determines EMI formula |
| `processingFeePercent` | BigDecimal | Processing fee as a percentage |
| `status` | ProductStatus | default=ACTIVE |

---

### 10.9 LoanApplication

**Table:** `loan_applications`

Central entity of the loan origination workflow. Its `status` field progresses through the application state machine.

| Column | Type | Description |
|--------|------|-------------|
| `applicationID` | Long | PK, AUTO |
| `borrowerID` | Long | NOT NULL |
| `groupID` | Long | nullable — for JLG group lending |
| `loanProductID` | Long | NOT NULL |
| `requestedAmount` | BigDecimal | Amount requested by the borrower |
| `purpose` | String | Purpose of the loan |
| `applicationDate` | LocalDate | default=`LocalDate.now()` |
| `creditOfficerID` | Long | FK → User (assigned Credit Officer) |
| `status` | ApplicationStatus | default=DRAFT — progresses through state machine |

---

### 10.10 CreditAssessment

**Table:** `credit_assessments`

Created by a Credit Officer after reviewing a borrower's profile. The `recommendation` field informs the approval decision.

| Column | Type | Description |
|--------|------|-------------|
| `assessmentID` | Long | PK, AUTO |
| `borrowerID` | Long | NOT NULL |
| `assessedByID` | Long | FK → User (Credit Officer) |
| `assessmentDate` | LocalDate | Defaults to `LocalDate.now()` |
| `internalCreditScore` | Integer | Internal credit score 0–1000 |
| `debtBurdenRatio` | BigDecimal | Existing obligations / monthly income × 100 (%) |
| `recommendation` | CreditRecommendation | ELIGIBLE / NOT_ELIGIBLE / CONDITIONAL |
| `remarks` | String | Up to 1000 characters — notes supporting the recommendation |

---

### 10.11 SanctionLetter

**Table:** `sanction_letters`

Issued after an application is APPROVED. The borrower must accept the letter before disbursement can proceed.

| Column | Type | Constraint | Description |
|--------|------|-----------|-------------|
| `sanctionID` | Long | PK, AUTO | |
| `applicationID` | Long | UNIQUE — one sanction per application | |
| `sanctionedAmount` | BigDecimal | | Approved amount (may differ from requested) |
| `interestRate` | BigDecimal | | Rate applicable to this sanction |
| `tenure` | Integer | | Tenure in months |
| `emiAmount` | BigDecimal | | Pre-calculated EMI amount |
| `disbursalConditions` | String | up to 1000 chars | Conditions borrower must meet |
| `issuedDate` | LocalDate | default=today | |
| `acceptedByBorrower` | Boolean | default=false | Must be `true` before `POST /api/loan-accounts/disburse` |
| `status` | SanctionStatus | default=ISSUED | ISSUED → ACCEPTED (→ LAPSED if not acted on) |

---

### 10.12 LoanAccount

**Table:** `loan_accounts`

Created atomically with N `RepaymentSchedule` rows during disbursement. The `dpd` field and `status` are updated nightly by the `DelinquencyScheduler`.

| Column | Type | Description |
|--------|------|-------------|
| `loanAccountID` | Long | PK, AUTO |
| `applicationID` | Long | FK → LoanApplication |
| `borrowerID` | Long | FK → Borrower |
| `productID` | Long | FK → LoanProduct |
| `disbursedAmount` | BigDecimal | Principal disbursed |
| `disbursementDate` | LocalDate | Date of disbursement |
| `totalInterest` | BigDecimal | Pre-calculated total interest over full tenure |
| `totalRepayable` | BigDecimal | `disbursedAmount + totalInterest` |
| `outstandingPrincipal` | BigDecimal | Reduces as `CollectionServiceImpl` records payments |
| `dpd` | Integer | Days Past Due — updated nightly; default=0 |
| `status` | LoanAccountStatus | default=ACTIVE · NPA at dpd≥90 · CLOSED at full repayment |

---

### 10.13 RepaymentSchedule

**Table:** `repayment_schedules`

One row per installment. N rows are created atomically via `scheduleRepository.saveAll()` during disbursement. The `amountPaid` field supports cumulative partial payment tracking across multiple collection events.

| Column | Type | Description |
|--------|------|-------------|
| `scheduleID` | Long | PK, AUTO |
| `loanAccountID` | Long | NOT NULL — FK → LoanAccount |
| `installmentNumber` | Integer | 1 through N (tenure) |
| `dueDate` | LocalDate | `disbursementDate + installmentNumber months` |
| `principalDue` | BigDecimal | Principal component of this installment |
| `interestDue` | BigDecimal | Interest component |
| `totalDue` | BigDecimal | `principalDue + interestDue` |
| `amountPaid` | BigDecimal | Cumulative total paid toward this installment; default=ZERO |
| `paidDate` | LocalDate | Stamped when status transitions to PAID |
| `status` | InstallmentStatus | default=PENDING |

---

### 10.14 CollectionRecord

**Table:** `collection_records`

One row per payment transaction. A single installment may have multiple collection records if paid in installments over time.

| Column | Type | Description |
|--------|------|-------------|
| `collectionID` | Long | PK, AUTO |
| `loanAccountID` | Long | NOT NULL |
| `scheduleID` | Long | nullable — links to the specific `RepaymentSchedule` row |
| `collectedAmount` | BigDecimal | Amount collected in this transaction |
| `collectionDate` | LocalDate | default=today |
| `collectedByID` | Long | FK → User (Field Officer or Collections Officer) |
| `mode` | CollectionMode | CASH / BANK_TRANSFER / CENTRE_COLLECTION |
| `status` | CollectionStatus | RECEIVED (full) · PARTIAL · EXCESS (over-paid) |

---

### 10.15 DelinquencyCase

**Table:** `delinquency_cases`

Cases are created automatically by `DelinquencyScheduler` or manually via `POST /api/delinquency`. Collections Officers update the `action` and `status` fields as recovery progresses.

| Column | Type | Description |
|--------|------|-------------|
| `delinquencyID` | Long | PK, AUTO |
| `loanAccountID` | Long | NOT NULL |
| `dpd` | Integer | Days Past Due at case creation / latest update |
| `parBucket` | PARBucket | Classifies severity: PAR30 / PAR60 / PAR90 / PAR180 |
| `assignedCollectionsOfficerID` | Long | FK → User |
| `openedDate` | LocalDate | default=today — stamped when case is first opened |
| `action` | DelinquencyAction | FIELD_VISIT / LEGAL_NOTICE / RESTRUCTURING / WRITE_OFF |
| `status` | DelinquencyStatus | default=OPEN |

---

### 10.16 PortfolioReport

**Table:** `portfolio_reports`

Persisted snapshots generated on demand. Historical reports are retained to allow trend analysis.

| Column | Type | Description |
|--------|------|-------------|
| `reportID` | Long | PK, AUTO |
| `scope` | ReportScope | BRANCH / PRODUCT / FIELD_OFFICER / PERIOD |
| `scopeRefID` | Long | The ID of the scoped entity (branchID, productID, etc.) |
| `activeLoanCount` | Integer | Count of ACTIVE loan accounts |
| `totalOutstanding` | BigDecimal | Sum of `outstandingPrincipal` for ACTIVE accounts |
| `disbursementValue` | BigDecimal | Sum of `disbursedAmount` across all accounts |
| `collectionRate` | BigDecimal | Reserved for future calculation |
| `par30` | BigDecimal | Reserved for future PAR30 ratio |
| `par90` | BigDecimal | Reserved for future PAR90 ratio |
| `npaPercent` | BigDecimal | `(NPA account count / total account count) × 100` |
| `generatedDate` | LocalDate | default=today |

---

### 10.17 Notification

**Table:** `notifications`

In-app notification messages sent to individual users. Supports a three-state lifecycle.

| Column | Type | Description |
|--------|------|-------------|
| `notificationID` | Long | PK, AUTO |
| `userID` | Long | NOT NULL — FK → User (recipient) |
| `message` | String | Up to 500 characters |
| `category` | NotificationCategory | REPAYMENT / DISBURSEMENT / MEETING / DELINQUENCY / COMPLIANCE |
| `status` | NotificationStatus | default=UNREAD |
| `createdDate` | LocalDateTime | default=now |

---

## 11. Repository Layer

All 17 repositories extend `JpaRepository<Entity, Long>`, inheriting `findAll()`, `findById()`, `save()`, `saveAll()`, `deleteById()`, and `count()`.

| Repository | Custom Methods |
|-----------|----------------|
| `UserRepository` | `findByEmail(String)`, `existsByEmail(String)`, `findByRole(UserRole)`, `findByBranchID(Long)` |
| `AuditLogRepository` | Standard only |
| `BorrowerRepository` | `findByNationalIDNumber(String)`, `findByEmail(String)`, `findByStatus(BorrowerStatus)`, `findByVillage(String)` |
| `BorrowerKYCRepository` | `findByBorrowerID(Long)`, `findByStatus(KYCStatus)` |
| `BorrowerGroupRepository` | `findByCentreID(Long)`, `findByFieldOfficerID(Long)` |
| `CentreRepository` | Standard only |
| `CentreMeetingRepository` | `findByCentreID(Long)`, `findByConductedByID(Long)` |
| `LoanProductRepository` | Standard only |
| `LoanApplicationRepository` | `findByBorrowerID(Long)`, `findByStatus(ApplicationStatus)`, `findByCreditOfficerID(Long)`, `findByGroupID(Long)` |
| `CreditAssessmentRepository` | Standard only |
| `SanctionLetterRepository` | Standard only |
| `LoanAccountRepository` | `findByBorrowerID(Long)`, `findByStatus(LoanAccountStatus)`, `findByApplicationID(Long)` |
| `RepaymentScheduleRepository` | `findByLoanAccountID(Long)`, `findByLoanAccountIDAndStatus(Long, InstallmentStatus)`, `findByStatus(InstallmentStatus)`, `findOverdueInstallments(@Query)` |
| `CollectionRecordRepository` | `findByLoanAccountID(Long)`, `findByCollectedByID(Long)` |
| `DelinquencyCaseRepository` | `findByLoanAccountID(Long)`, `findByStatus(DelinquencyStatus)`, `findByAssignedCollectionsOfficerID(Long)`, `findByLoanAccountIDAndStatus(Long, DelinquencyStatus)` |
| `PortfolioReportRepository` | Standard only |
| `NotificationRepository` | `findByUserID(Long)`, `findByUserIDAndStatus(Long, NotificationStatus)` |

**Critical custom JPQL query** in `RepaymentScheduleRepository`:

```java
@Query("SELECT r FROM RepaymentSchedule r WHERE r.dueDate < :today AND r.status IN ('PENDING', 'PARTIAL')")
List<RepaymentSchedule> findOverdueInstallments(@Param("today") LocalDate today);
```

Used by `DelinquencyScheduler` each night to locate all installments that are past their due date and not yet fully paid. Both `PENDING` (no payment at all) and `PARTIAL` (partially paid) statuses are included because both represent outstanding obligations.

**Duplicate-prevention query** in `DelinquencyCaseRepository`:

```java
Optional<DelinquencyCase> findByLoanAccountIDAndStatus(Long loanAccountID, DelinquencyStatus status);
```

Used by the scheduler to check for an existing OPEN case before creating a duplicate.

---

## 12. Service Interfaces

The service layer is structured as **17 Java interfaces** in `service/` paired with **17 `@Service` implementation classes** in `service/impl/`. Controllers inject the interface type; Spring IoC injects the matching implementation.

Benefits of this pattern:
- **Testability** — unit tests mock the interface with Mockito, no database required
- **Dependency Inversion** — controllers depend on abstractions, not concrete classes
- **Replaceability** — alternative implementations can be substituted without touching controllers

| Interface | Methods |
|-----------|---------|
| `AuthService` | `register(RegisterUserRequest)`, `login(LoginRequest)` |
| `UserService` | `getAll()`, `getById(Long)`, `getByRole(UserRole)`, `updateStatus(Long, UserStatus)`, `delete(Long)` |
| `AuditLogService` | `log(Long, String, String)`, `getAllLogs()` |
| `BorrowerService` | `create(BorrowerRequest)`, `getAll()`, `getById(Long)`, `update(Long, BorrowerRequest)`, `delete(Long)`, `getByStatus(BorrowerStatus)`, `getByUserID(Long)` |
| `BorrowerKYCService` | `create(BorrowerKYCRequest)`, `getByBorrower(Long)`, `getById(Long)`, `updateStatus(Long, KYCStatus, Long)`, `getAll()` |
| `BorrowerGroupService` | `create(BorrowerGroupRequest)`, `getAll()`, `getById(Long)`, `update(Long, BorrowerGroupRequest)`, `getByCentre(Long)` |
| `CentreService` | `create(CentreRequest)`, `getAll()`, `getById(Long)`, `update(Long, CentreRequest)` |
| `CentreMeetingService` | `create(CentreMeetingRequest)`, `getAll()`, `getById(Long)`, `update(Long, CentreMeetingRequest)`, `getByCentre(Long)` |
| `LoanProductService` | `create(LoanProductRequest)`, `getAll()`, `getById(Long)`, `update(Long, LoanProductRequest)`, `discontinue(Long)` |
| `LoanApplicationService` | `create(LoanApplicationRequest)`, `getAll()`, `getById(Long)`, `getByBorrower(Long)`, `getByStatus(ApplicationStatus)`, `updateStatus(Long, LoanApplicationStatusRequest)`, `submit(Long)` |
| `CreditAssessmentService` | `create(CreditAssessmentRequest)`, `getAll()`, `getById(Long)`, `update(Long, CreditAssessmentRequest)` |
| `SanctionLetterService` | `issue(SanctionLetterRequest)`, `accept(Long)`, `getById(Long)`, `getByApplicationId(Long)`, `getAll()` |
| `LoanDisbursementService` | `disburse(DisbursementRequest)`, `getById(Long)`, `getAll()`, `getByBorrower(Long)`, `getSchedule(Long)` |
| `CollectionService` | `recordCollection(CollectionRequest)`, `getAll()`, `getByLoanAccount(Long)`, `getById(Long)` |
| `DelinquencyService` | `create(DelinquencyCaseRequest)`, `getAll()`, `getById(Long)`, `update(Long, DelinquencyCaseRequest)`, `getByStatus(DelinquencyStatus)`, `getByOfficer(Long)`, `getByLoanAccount(Long)` |
| `PortfolioReportService` | `generate(ReportScope, Long)`, `getAll()`, `getById(Long)` |
| `NotificationService` | `send(Long, String, NotificationCategory)`, `getByUser(Long)`, `getUnreadByUser(Long)`, `markRead(Long)`, `dismiss(Long)`, `getAll()` |

---

## 13. Service Implementations

### 13.1 AuthServiceImpl

**`register(RegisterUserRequest request)`**

1. Check `userRepository.existsByEmail(request.getEmail())` — throws `BadRequestException` if the email is already registered.
2. Read `SecurityContextHolder.getContext().getAuthentication()` to identify the caller's role.
3. If the caller is `ROLE_BRANCH_MANAGER`, call `validateBranchManagerProvisioning(auth, request)`:
   - `request.getRole()` must be in `MANAGER_PROVISIONABLE_ROLES` = `[FIELD_OFFICER, CREDIT_OFFICER, COLLECTIONS_OFFICER]` — otherwise throws `SecurityException`.
   - `caller.getBranchID()` must equal `request.getBranchID()` — cross-branch provisioning throws `SecurityException`.
4. Build `User` entity with `passwordEncoder.encode(request.getPassword())`.
5. Save user, generate JWT, return `AuthResponse`.

**`login(LoginRequest request)`**

1. Call `authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(email, password))`. Spring Security internally calls `CustomUserDetailsService` and `BCryptPasswordEncoder.matches()`. Throws `BadCredentialsException` on mismatch.
2. Load user from repository by email.
3. Generate JWT and return `AuthResponse`.

---

### 13.2 UserServiceImpl

Standard CRUD delegating entirely to `UserRepository`. `updateStatus(id, status)` sets the `UserStatus` value — setting `SUSPENDED` prevents login because `User.isAccountNonLocked()` returns false.

---

### 13.3 AuditLogServiceImpl

**`log(userID, action, module)`** — builds an `AuditLog` entity with `timestamp = LocalDateTime.now()` and persists it.

**`getAllLogs()`** — returns all audit log entries. Called by `AuditLogController` for Admin review.

The `DelinquencyScheduler` calls `log(0L, "AUTO_CREATE_DELINQUENCY_CASE", "DELINQUENCY")` using `userID=0` to tag system-generated events, distinguishing them from user-initiated actions in the audit trail.

---

### 13.4 BorrowerServiceImpl

**`create(BorrowerRequest request)`**

1. **National ID dedup** — `findByNationalIDNumber(nationalIDNumber)` — throws `BadRequestException("Borrower with National ID already exists")` if present.
2. **Email dedup** — `userRepository.existsByEmail(email)` — throws `BadRequestException("Email already used")` if taken.
3. Create and save `User` entity: `role=BORROWER`, `email=request.getEmail()`, `password=BCrypt(request.getPassword())`.
4. Create and save `Borrower` entity with `user = savedUser` (sets the `@OneToOne` FK column `user_id`).

**`delete(Long id)`** — loads the borrower, deletes the linked `User` first (`userRepository.deleteById(user.getUserID())`), then deletes the `Borrower`. Prevents orphaned login accounts.

**`getByUserID(Long userID)`** — streams all borrowers and finds the one whose `user.getUserID()` matches. Used when a logged-in BORROWER looks up their own profile.

**`update(Long id, BorrowerRequest request)`** — null-safe partial update: only updates a field if the corresponding request field is non-null. `name` is always updated.

---

### 13.5 BorrowerKYCServiceImpl

**`create(BorrowerKYCRequest request)`** — saves a new `BorrowerKYC` record with `status=PENDING`. The document is not yet verified.

**`updateStatus(id, status, verifiedByID)`** — sets `status` and `verifiedByID` then saves. Used by Credit Officers to VERIFY or REJECT uploaded documents.

---

### 13.6 BorrowerGroupServiceImpl

**`create(BorrowerGroupRequest request)`** — defaults: `formationDate = LocalDate.now()` if null, `memberCount = 0` if null, `jointLiabilityEnabled = false` if null, `status = ACTIVE` if null.

**`getByCentre(Long centreID)`** — delegates to `groupRepository.findByCentreID(centreID)`.

---

### 13.7 CentreServiceImpl

**`create(CentreRequest request)`** — defaults: `status = ACTIVE` if null.

**`update(Long id, CentreRequest request)`** — null-safe: always updates `centreName`; conditionally updates `fieldOfficerID`, `meetingDay`, `meetingTime`, `status` only when non-null.

---

### 13.8 CentreMeetingServiceImpl

**`create(CentreMeetingRequest request)`** — defaults: `meetingDate = LocalDate.now()`, `attendanceCount = 0`, `collectionAmount = BigDecimal.ZERO`, `status = SCHEDULED`.

**`update(Long id, CentreMeetingRequest request)`** — null-safe updates on `attendanceCount`, `collectionAmount`, `status`. Used after a meeting is conducted to record the outcome.

---

### 13.9 LoanProductServiceImpl

**`discontinue(Long id)`** — soft-delete: sets `status = ProductStatus.DISCONTINUED`. Existing disbursed loans are not affected; the product is simply no longer available for new applications.

---

### 13.10 LoanApplicationServiceImpl

Contains the loan application state machine. Every status change is validated by `validateStatusTransition(current, next)`:

```java
boolean valid = switch (current) {
    case DRAFT        -> next == ApplicationStatus.SUBMITTED;
    case SUBMITTED    -> next == ApplicationStatus.UNDER_REVIEW;
    case UNDER_REVIEW -> next == ApplicationStatus.APPROVED || next == ApplicationStatus.REJECTED;
    case APPROVED     -> next == ApplicationStatus.DISBURSED;
    default           -> false;
};
if (!valid) throw new BadRequestException("Invalid status transition from " + current + " to " + next);
```

**`create(LoanApplicationRequest request)`** — always sets `status = ApplicationStatus.DRAFT` regardless of any status value in the request.

**`submit(Long id)`** — explicitly validates `status == DRAFT` before setting `SUBMITTED`. Provides a clearer error message than the generic state machine check.

---

### 13.11 CreditAssessmentServiceImpl

**`create(CreditAssessmentRequest request)`** — defaults `assessmentDate = LocalDate.now()` if null.

**`update(Long id, CreditAssessmentRequest request)`** — null-safe updates on `internalCreditScore`, `debtBurdenRatio`, `recommendation`, `remarks`.

---

### 13.12 SanctionLetterServiceImpl

**`issue(SanctionLetterRequest request)`** — validates `application.status == ApplicationStatus.APPROVED`; throws `BadRequestException("Sanction letter only for APPROVED applications")` otherwise. The `applicationID` column has a `UNIQUE` constraint ensuring a maximum of one sanction letter per application.

**`accept(Long id)`** — validates `letter.status == SanctionStatus.ISSUED`; throws `BadRequestException("Only ISSUED letters can be accepted")` otherwise. Sets `acceptedByBorrower = true` and `status = ACCEPTED`. The `acceptedByBorrower = true` flag is the prerequisite checked in `LoanDisbursementServiceImpl` before a loan can be disbursed.

---

### 13.13 LoanDisbursementServiceImpl

Annotated `@Transactional` — the entire disbursement operation is atomic.

**`disburse(DisbursementRequest request)`**

1. Load `LoanApplication` by `applicationID` — throw 404 if not found.
2. Validate `application.status == APPROVED` — throw 400 if not.
3. Load `LoanProduct` to obtain `interestRatePercent`, `tenureMonths`, and `interestType`.
4. Calculate EMI:
   - **FLAT:** `totalInterest = P × R × T / 1200`; `EMI = (P + totalInterest) / T`
   - **REDUCING:** `r = R/1200`; `EMI = P × r × (1+r)^T / ((1+r)^T − 1)`; `totalInterest = EMI × T − P`
5. Create and save `LoanAccount` with `status=ACTIVE`, `dpd=0`, `outstandingPrincipal = principal`.
6. Set `application.status = DISBURSED` and save.
7. Call `generateSchedule()` which loops `i = 1..tenure`:
   - **FLAT:** each row has equal `principalDue = P / tenure` and `interestDue = P × R / 1200`
   - **REDUCING:** `interestDue = remainingPrincipal × monthlyRate`; `principalDue = EMI − interestDue`; `remainingPrincipal -= principalDue`
   - **Last installment:** `principalDue = remainingPrincipal` (rounding correction, ensures outstanding reaches exactly zero)
   - All rows: `dueDate = disbursementDate + i months`, `status = PENDING`
   - All N rows saved in a single `scheduleRepository.saveAll(schedules)` call

---

### 13.14 CollectionServiceImpl

Annotated `@Transactional`.

**`recordCollection(CollectionRequest request)`**

1. Load `LoanAccount` — throw 404 if not found.
2. Validate `account.status != CLOSED` — throw 400 if already closed.
3. Validate `collectedAmount > 0` — throw 400 if zero or negative.
4. If `scheduleID` is present in the request:
   - Load `RepaymentSchedule` — throw 404 if not found.
   - Compute `alreadyPaid` (from `amountPaid` field, default=ZERO) and `remainingDue = totalDue − alreadyPaid`.
   - **Full or excess payment** (`collected >= remaining`): `schedule.status = PAID`, `amountPaid = totalDue`, `paidDate = today`; `collectionStatus = RECEIVED` or `EXCESS` if over-paid.
   - **Partial payment** (`collected < remaining`): `schedule.amountPaid += collected` (cumulative, supports multiple partial payments over time), `schedule.status = PARTIAL`; `collectionStatus = PARTIAL`.
   - Save the updated schedule row.
5. Reduce `account.outstandingPrincipal = max(0, outstanding − collected)`.
6. If `outstandingPrincipal == 0`: `account.status = CLOSED` (loan fully repaid).
7. Save updated account.
8. Build and save `CollectionRecord` with the determined `collectionStatus`.

---

### 13.15 DelinquencyServiceImpl

Standard CRUD for manual delinquency case management. All automated detection logic lives in `DelinquencyScheduler`.

**`create(DelinquencyCaseRequest request)`** — sets `openedDate = LocalDate.now()`, defaults `status = OPEN`.

**`update(Long id, DelinquencyCaseRequest request)`** — null-safe updates on `dpd`, `parBucket`, `action`, `status`, `assignedCollectionsOfficerID`.

---

### 13.16 PortfolioReportServiceImpl

**`generate(ReportScope scope, Long scopeRefID)`**

1. Load all `LoanAccount` records.
2. Count `ACTIVE` accounts and sum their `outstandingPrincipal`.
3. Sum `disbursedAmount` across all accounts (total historical disbursement value).
4. Count `NPA` accounts; compute `npaPercent = (NPA count / total count) × 100` (rounded to 2 decimal places).
5. Build and persist `PortfolioReport`. `par30`, `par90`, and `collectionRate` are currently stored as `BigDecimal.ZERO` — reserved for future PAR calculation implementation.

---

### 13.17 NotificationServiceImpl

**`send(userID, message, category)`** — creates `Notification` with `status = UNREAD`, `createdDate = LocalDateTime.now()`, and saves.

**`markRead(Long id)`** — sets `status = READ`.

**`dismiss(Long id)`** — sets `status = DISMISSED`.

**`getUnreadByUser(Long userID)`** — delegates to `notificationRepository.findByUserIDAndStatus(userID, NotificationStatus.UNREAD)`.

---

## 14. Controller Layer — REST API

All 17 controllers share the following structure:
- `@RestController` + `@RequestMapping` + `@RequiredArgsConstructor`
- Inject the service **interface** (not the implementation)
- Return `ResponseEntity<ApiResponse<T>>` for all responses
- Apply `@Valid` on `@RequestBody` parameters to trigger DTO validation
- Apply `@PreAuthorize` on each method for method-level RBAC

### 14.1 AuthController

**Base path:** `/api/auth`

| Method | Path | Roles | Response | Description |
|--------|------|-------|----------|-------------|
| POST | `/login` | PUBLIC | `AuthResponse` | Authenticate and receive JWT |
| POST | `/register` | ADMIN, BRANCH_MANAGER | `AuthResponse` | Create staff account; scope validated in service |

---

### 14.2 UserController

**Base path:** `/api/admin/users` | All endpoints: `hasRole('ADMIN')`

| Method | Path | Description |
|--------|------|-------------|
| GET | `/` | List all staff users |
| GET | `/{id}` | Get user by ID |
| GET | `/role/{role}` | Filter users by `UserRole` |
| PATCH | `/{id}/status?status=` | Activate or suspend a user account |
| DELETE | `/{id}` | Hard delete a user |

---

### 14.3 AuditLogController

**Base path:** `/api/admin/audit-logs` | All endpoints: `hasRole('ADMIN')`

| Method | Path | Description |
|--------|------|-------------|
| GET | `/` | Retrieve all audit log entries |

---

### 14.4 BorrowerController

**Base path:** `/api/borrowers`

| Method | Path | Roles | Description |
|--------|------|-------|-------------|
| POST | `/` | ADMIN, CREDIT, FIELD | Register borrower; auto-creates linked User account |
| GET | `/` | ADMIN, CREDIT, FIELD, BRANCH | List all borrowers |
| GET | `/{id}` | ADMIN, CREDIT, FIELD, BRANCH | Borrower by ID |
| PUT | `/{id}` | ADMIN, CREDIT | Update borrower (null-safe partial update) |
| DELETE | `/{id}` | ADMIN | Delete borrower and linked User account |
| GET | `/status/{status}` | ADMIN, CREDIT, BRANCH | Filter by BorrowerStatus |

---

### 14.5 KYCController

**Base path:** `/api/kyc`

| Method | Path | Roles | Description |
|--------|------|-------|-------------|
| POST | `/` | ADMIN, CREDIT, FIELD | Upload KYC document (sets status=PENDING) |
| GET | `/` | ADMIN, CREDIT | List all KYC records |
| GET | `/{id}` | ADMIN, CREDIT, BRANCH | Single KYC record by ID |
| GET | `/borrower/{borrowerID}` | ADMIN, CREDIT, BRANCH | All KYC documents for a borrower |
| PATCH | `/{id}/verify?status=&verifiedByID=` | **ADMIN, CREDIT only** | Verify or reject a KYC document |

The `PATCH /verify` endpoint is restricted to ADMIN and CREDIT_OFFICER at both the route level (`SecurityConfig`) and the method level (`@PreAuthorize`), ensuring a Field Officer who uploads a document cannot also verify it.

---

### 14.6 BorrowerGroupController

**Base path:** `/api/groups`

| Method | Path | Roles | Description |
|--------|------|-------|-------------|
| POST | `/` | ADMIN, FIELD, BRANCH | Create JLG group |
| GET | `/` | ADMIN, FIELD, BRANCH | List all groups |
| GET | `/{id}` | ADMIN, FIELD, BRANCH | Group by ID |
| PUT | `/{id}` | ADMIN, FIELD, BRANCH | Update group details |
| GET | `/centre/{centreID}` | ADMIN, FIELD, BRANCH | All groups within a centre |

---

### 14.7 CentreController

**Base path:** `/api/centres`

| Method | Path | Roles | Description |
|--------|------|-------|-------------|
| POST | `/` | ADMIN, BRANCH, FIELD | Create village centre |
| GET | `/` | ADMIN, FIELD, BRANCH | List all centres |
| GET | `/{id}` | ADMIN, FIELD, BRANCH | Centre by ID |
| PUT | `/{id}` | ADMIN, BRANCH | Update centre details |

---

### 14.8 CentreMeetingController

**Base path:** `/api/meetings`

| Method | Path | Roles | Description |
|--------|------|-------|-------------|
| POST | `/` | ADMIN, FIELD, BRANCH | Schedule a centre meeting |
| GET | `/` | ADMIN, FIELD, BRANCH | List all meetings |
| GET | `/{id}` | ADMIN, FIELD, BRANCH | Meeting by ID |
| PUT | `/{id}` | ADMIN, FIELD | Record attendance count, collection amount, and status |
| GET | `/centre/{centreID}` | ADMIN, FIELD, BRANCH | All meetings for a specific centre |

---

### 14.9 LoanProductController

**Base path:** `/api/loan-products`

| Method | Path | Roles | Description |
|--------|------|-------|-------------|
| POST | `/` | ADMIN | Create new loan product |
| GET | `/` | No auth required | List all products |
| GET | `/{id}` | No auth required | Product by ID |
| PUT | `/{id}` | ADMIN | Update product parameters |
| PATCH | `/{id}/discontinue` | ADMIN | Soft-delete — sets status=DISCONTINUED |

---

### 14.10 LoanApplicationController

**Base path:** `/api/loan-applications`

| Method | Path | Roles | Description |
|--------|------|-------|-------------|
| POST | `/` | ADMIN, CREDIT, FIELD | Create application (always starts as DRAFT) |
| GET | `/` | ADMIN, CREDIT, BRANCH, FIELD | List all applications |
| GET | `/{id}` | ADMIN, CREDIT, BORROWER, BRANCH, FIELD | Application by ID |
| GET | `/borrower/{borrowerID}` | ADMIN, CREDIT, BORROWER, BRANCH, FIELD | Applications for a borrower |
| GET | `/status/{status}` | ADMIN, CREDIT, BRANCH, FIELD | Filter by ApplicationStatus |
| PATCH | `/{id}/submit` | ADMIN, CREDIT, BORROWER, FIELD | DRAFT → SUBMITTED |
| PATCH | `/{id}/status` | ADMIN, CREDIT | State machine transitions |

---

### 14.11 CreditAssessmentController

**Base path:** `/api/credit-assessments`

| Method | Path | Roles | Description |
|--------|------|-------|-------------|
| POST | `/` | ADMIN, CREDIT | Create credit assessment |
| GET | `/` | ADMIN, CREDIT, BRANCH | List all assessments |
| GET | `/{id}` | ADMIN, CREDIT | Assessment by ID |
| PUT | `/{id}` | ADMIN, CREDIT | Update score, DBR, recommendation, remarks |

---

### 14.12 SanctionLetterController

**Base path:** `/api/sanction-letters`

| Method | Path | Roles | Description |
|--------|------|-------|-------------|
| POST | `/` | ADMIN, CREDIT | Issue sanction letter (application must be APPROVED) |
| GET | `/` | ADMIN, CREDIT, BRANCH | List all sanction letters |
| GET | `/{id}` | ADMIN, CREDIT, BORROWER | Sanction letter by ID |
| GET | `/application/{applicationID}` | ADMIN, CREDIT, BORROWER | Sanction for a specific application |
| PATCH | `/{id}/accept` | ADMIN, BORROWER, CREDIT, FIELD | Borrower accepts — status → ACCEPTED |

---

### 14.13 LoanAccountController

**Base path:** `/api/loan-accounts`

| Method | Path | Roles | Description |
|--------|------|-------|-------------|
| POST | `/disburse` | ADMIN, CREDIT | Disburse loan — creates account and generates N schedule rows |
| GET | `/` | ADMIN, CREDIT, BRANCH, COLLECTIONS | List all loan accounts |
| GET | `/{id}` | ADMIN, CREDIT, BORROWER, BRANCH, COLLECTIONS | Loan account by ID |
| GET | `/borrower/{borrowerID}` | ADMIN, CREDIT, BORROWER, BRANCH, FIELD | All loans for a borrower |
| GET | `/{id}/schedule` | ADMIN, CREDIT, BORROWER, FIELD, COLLECTIONS | Full repayment schedule |

---

### 14.14 CollectionController

**Base path:** `/api/collections`

| Method | Path | Roles | Description |
|--------|------|-------|-------------|
| POST | `/` | ADMIN, FIELD, COLLECTIONS | Record EMI payment (full, partial, or excess) |
| GET | `/` | ADMIN, BRANCH, COLLECTIONS | List all collection records |
| GET | `/{id}` | ADMIN, FIELD, COLLECTIONS, BRANCH | Collection record by ID |
| GET | `/loan-account/{loanAccountID}` | ADMIN, FIELD, COLLECTIONS, BRANCH, BORROWER | All payments for a loan account |

---

### 14.15 DelinquencyController

**Base path:** `/api/delinquency`

| Method | Path | Roles | Description |
|--------|------|-------|-------------|
| POST | `/` | ADMIN, COLLECTIONS, BRANCH | Manually open a delinquency case |
| GET | `/` | ADMIN, COLLECTIONS, BRANCH | List all cases |
| GET | `/{id}` | ADMIN, COLLECTIONS, BRANCH | Case by ID |
| PUT | `/{id}` | ADMIN, COLLECTIONS | Update action, status, DPD, PAR bucket |
| GET | `/status/{status}` | ADMIN, COLLECTIONS, BRANCH | Cases by DelinquencyStatus |
| GET | `/officer/{officerID}` | ADMIN, COLLECTIONS, BRANCH | Cases assigned to an officer |
| GET | `/loan-account/{loanAccountID}` | ADMIN, COLLECTIONS, BRANCH | Cases for a loan account |
| POST | `/trigger` | ADMIN only | Manually invoke the nightly delinquency engine |

---

### 14.16 PortfolioReportController

**Base path:** `/api/reports`

| Method | Path | Roles | Description |
|--------|------|-------|-------------|
| POST | `/generate?scope=BRANCH&scopeRefID=1` | ADMIN, BRANCH | Generate and persist a portfolio snapshot |
| GET | `/` | ADMIN, BRANCH | List all generated reports |
| GET | `/{id}` | ADMIN, BRANCH | Report by ID |

---

### 14.17 NotificationController

**Base path:** `/api/notifications`

| Method | Path | Roles | Description |
|--------|------|-------|-------------|
| POST | `/send?userID=&message=&category=` | ADMIN | Send notification to a specific user |
| GET | `/user/{userID}` | Authenticated | All notifications for a user |
| GET | `/user/{userID}/unread` | Authenticated | Unread notifications only |
| PATCH | `/{id}/read` | Authenticated | Mark a notification as READ |
| PATCH | `/{id}/dismiss` | Authenticated | Dismiss a notification |
| GET | `/` | ADMIN | All notifications across all users |

---

## 15. Automated Delinquency Scheduler

`DelinquencyScheduler` is a `@Component` containing the automated nightly delinquency detection engine. It operates independently of any HTTP request.

**Cron schedule:** `0 30 0 * * *` — fires every day at 00:30 AM.  
**Transactional:** All operations within each run are wrapped in `@Transactional`.  
**Requires:** `@EnableScheduling` on `MicroLendApplication` and `spring.task.scheduling.pool.size=5` in properties.

### Engine Algorithm

```
1. QUERY
   ── scheduleRepository.findOverdueInstallments(today)
   ── WHERE dueDate < today AND status IN ('PENDING', 'PARTIAL')

2. FOR EACH overdue installment:

   a. MARK OVERDUE
      ── if installment.status != OVERDUE → installment.status = OVERDUE; save

   b. CALCULATE DPD
      ── daysOverdue = ChronoUnit.DAYS.between(installment.dueDate, today)

   c. UPDATE ACCOUNT DPD
      ── account.dpd = max(account.dpd, daysOverdue); save

   d. CLASSIFY NPA
      ── if daysOverdue >= 90 AND account.status == ACTIVE
         → account.status = NPA  (logged at WARN level)

   e. CLASSIFY PAR BUCKET
      ── daysOverdue >= 180 → PAR180
      ── daysOverdue >=  90 → PAR90
      ── daysOverdue >=  60 → PAR60
      ── daysOverdue >=  30 → PAR30

   f. CREATE OR UPDATE DELINQUENCY CASE
      ── delinquencyRepository.findByLoanAccountIDAndStatus(id, OPEN)
         EXISTS  → update dpd + parBucket; save
         MISSING → create new DelinquencyCase(loanAccountID, dpd, parBucket, openedDate=today, status=OPEN); save

   g. WRITE AUDIT LOG  (new cases only)
      ── auditLogRepository.save(AuditLog(userID=0, action="AUTO_CREATE_DELINQUENCY_CASE", module="DELINQUENCY"))

3. LOG SUMMARY
   ── "OVERDUE marked: X | Cases created: Y | Cases updated: Z"
```

### Manual Trigger

`POST /api/delinquency/trigger` (ADMIN only) calls `delinquencyScheduler.triggerManualRun()`, which delegates to `runNightlyDelinquencyCheck()`. Useful for testing, system recovery, and backfilling after downtime. The automatic scheduled run is unaffected.

---

## 16. Complete API Reference

| # | Method | Endpoint | Min Role | Description |
|---|--------|----------|----------|-------------|
| 1 | POST | `/api/auth/login` | PUBLIC | Authenticate — returns JWT |
| 2 | POST | `/api/auth/register` | ADMIN / BM | Create staff account |
| 3 | GET | `/api/admin/users` | ADMIN | List all users |
| 4 | GET | `/api/admin/users/{id}` | ADMIN | User by ID |
| 5 | GET | `/api/admin/users/role/{role}` | ADMIN | Users by role |
| 6 | PATCH | `/api/admin/users/{id}/status` | ADMIN | Activate / suspend user |
| 7 | DELETE | `/api/admin/users/{id}` | ADMIN | Delete user |
| 8 | GET | `/api/admin/audit-logs` | ADMIN | All audit entries |
| 9 | POST | `/api/loan-products` | ADMIN | Create product |
| 10 | GET | `/api/loan-products` | PUBLIC | List products |
| 11 | GET | `/api/loan-products/{id}` | PUBLIC | Product by ID |
| 12 | PUT | `/api/loan-products/{id}` | ADMIN | Update product |
| 13 | PATCH | `/api/loan-products/{id}/discontinue` | ADMIN | Discontinue product |
| 14 | POST | `/api/borrowers` | ADMIN/CREDIT/FIELD | Register borrower |
| 15 | GET | `/api/borrowers` | ADMIN/CREDIT/FIELD/BRANCH | List borrowers |
| 16 | GET | `/api/borrowers/{id}` | ADMIN/CREDIT/FIELD/BRANCH | Borrower by ID |
| 17 | PUT | `/api/borrowers/{id}` | ADMIN/CREDIT | Update borrower |
| 18 | DELETE | `/api/borrowers/{id}` | ADMIN | Delete borrower |
| 19 | GET | `/api/borrowers/status/{status}` | ADMIN/CREDIT/BRANCH | Filter by status |
| 20 | POST | `/api/kyc` | ADMIN/CREDIT/FIELD | Upload KYC document |
| 21 | GET | `/api/kyc` | ADMIN/CREDIT | All KYC records |
| 22 | GET | `/api/kyc/{id}` | ADMIN/CREDIT/BRANCH | KYC record by ID |
| 23 | GET | `/api/kyc/borrower/{id}` | ADMIN/CREDIT/BRANCH | KYC for a borrower |
| 24 | PATCH | `/api/kyc/{id}/verify` | ADMIN/CREDIT | Verify or reject KYC |
| 25 | POST | `/api/centres` | ADMIN/BRANCH/FIELD | Create centre |
| 26 | GET | `/api/centres` | ADMIN/FIELD/BRANCH | List centres |
| 27 | GET | `/api/centres/{id}` | ADMIN/FIELD/BRANCH | Centre by ID |
| 28 | PUT | `/api/centres/{id}` | ADMIN/BRANCH | Update centre |
| 29 | POST | `/api/groups` | ADMIN/FIELD/BRANCH | Create JLG group |
| 30 | GET | `/api/groups` | ADMIN/FIELD/BRANCH | List groups |
| 31 | GET | `/api/groups/{id}` | ADMIN/FIELD/BRANCH | Group by ID |
| 32 | PUT | `/api/groups/{id}` | ADMIN/FIELD/BRANCH | Update group |
| 33 | GET | `/api/groups/centre/{id}` | ADMIN/FIELD/BRANCH | Groups by centre |
| 34 | POST | `/api/meetings` | ADMIN/FIELD/BRANCH | Schedule meeting |
| 35 | GET | `/api/meetings` | ADMIN/FIELD/BRANCH | List meetings |
| 36 | GET | `/api/meetings/{id}` | ADMIN/FIELD/BRANCH | Meeting by ID |
| 37 | PUT | `/api/meetings/{id}` | ADMIN/FIELD | Update meeting outcome |
| 38 | GET | `/api/meetings/centre/{id}` | ADMIN/FIELD/BRANCH | Meetings by centre |
| 39 | POST | `/api/loan-applications` | ADMIN/CREDIT/FIELD | Create application |
| 40 | GET | `/api/loan-applications` | ADMIN/CREDIT/BRANCH/FIELD | List all |
| 41 | GET | `/api/loan-applications/{id}` | ADMIN/CREDIT/BORROWER/BRANCH/FIELD | By ID |
| 42 | GET | `/api/loan-applications/borrower/{id}` | ADMIN/CREDIT/BORROWER/BRANCH/FIELD | By borrower |
| 43 | GET | `/api/loan-applications/status/{s}` | ADMIN/CREDIT/BRANCH/FIELD | By status |
| 44 | PATCH | `/api/loan-applications/{id}/submit` | ADMIN/CREDIT/BORROWER/FIELD | DRAFT → SUBMITTED |
| 45 | PATCH | `/api/loan-applications/{id}/status` | ADMIN/CREDIT | State transition |
| 46 | POST | `/api/credit-assessments` | ADMIN/CREDIT | Create assessment |
| 47 | GET | `/api/credit-assessments` | ADMIN/CREDIT/BRANCH | List all |
| 48 | GET | `/api/credit-assessments/{id}` | ADMIN/CREDIT | By ID |
| 49 | PUT | `/api/credit-assessments/{id}` | ADMIN/CREDIT | Update |
| 50 | POST | `/api/sanction-letters` | ADMIN/CREDIT | Issue sanction letter |
| 51 | GET | `/api/sanction-letters` | ADMIN/CREDIT/BRANCH | List all |
| 52 | GET | `/api/sanction-letters/{id}` | ADMIN/CREDIT/BORROWER | By ID |
| 53 | GET | `/api/sanction-letters/application/{id}` | ADMIN/CREDIT/BORROWER | By application |
| 54 | PATCH | `/api/sanction-letters/{id}/accept` | ADMIN/BORROWER/CREDIT/FIELD | Accept sanction |
| 55 | POST | `/api/loan-accounts/disburse` | ADMIN/CREDIT | Disburse loan |
| 56 | GET | `/api/loan-accounts` | ADMIN/CREDIT/BRANCH/COLLECTIONS | List accounts |
| 57 | GET | `/api/loan-accounts/{id}` | ADMIN/CREDIT/BORROWER/BRANCH/COLLECTIONS | By ID |
| 58 | GET | `/api/loan-accounts/borrower/{id}` | ADMIN/CREDIT/BORROWER/BRANCH/FIELD | By borrower |
| 59 | GET | `/api/loan-accounts/{id}/schedule` | ADMIN/CREDIT/BORROWER/FIELD/COLLECTIONS | Repayment schedule |
| 60 | POST | `/api/collections` | ADMIN/FIELD/COLLECTIONS | Record payment |
| 61 | GET | `/api/collections` | ADMIN/BRANCH/COLLECTIONS | List all |
| 62 | GET | `/api/collections/{id}` | ADMIN/FIELD/COLLECTIONS/BRANCH | By ID |
| 63 | GET | `/api/collections/loan-account/{id}` | ADMIN/FIELD/COLLECTIONS/BRANCH/BORROWER | By loan |
| 64 | POST | `/api/delinquency` | ADMIN/COLLECTIONS/BRANCH | Open case |
| 65 | GET | `/api/delinquency` | ADMIN/COLLECTIONS/BRANCH | List cases |
| 66 | GET | `/api/delinquency/{id}` | ADMIN/COLLECTIONS/BRANCH | By ID |
| 67 | PUT | `/api/delinquency/{id}` | ADMIN/COLLECTIONS | Update case |
| 68 | GET | `/api/delinquency/status/{s}` | ADMIN/COLLECTIONS/BRANCH | By status |
| 69 | GET | `/api/delinquency/officer/{id}` | ADMIN/COLLECTIONS/BRANCH | By officer |
| 70 | GET | `/api/delinquency/loan-account/{id}` | ADMIN/COLLECTIONS/BRANCH | By loan account |
| 71 | POST | `/api/delinquency/trigger` | ADMIN | Manual engine trigger |
| 72 | POST | `/api/reports/generate` | ADMIN/BRANCH | Generate report |
| 73 | GET | `/api/reports` | ADMIN/BRANCH | List reports |
| 74 | GET | `/api/reports/{id}` | ADMIN/BRANCH | Report by ID |
| 75 | POST | `/api/notifications/send` | ADMIN | Send notification |
| 76 | GET | `/api/notifications/user/{id}` | Authenticated | User's notifications |
| 77 | GET | `/api/notifications/user/{id}/unread` | Authenticated | Unread only |
| 78 | PATCH | `/api/notifications/{id}/read` | Authenticated | Mark as read |
| 79 | PATCH | `/api/notifications/{id}/dismiss` | Authenticated | Dismiss |
| 80 | GET | `/api/notifications` | ADMIN | All notifications |

---

## 17. Role-Based Access Control Matrix

| Resource / Operation | ADMIN | BRANCH_MGR | CREDIT | FIELD | COLLECTIONS | BORROWER |
|---------------------|-------|-----------|--------|-------|-------------|---------|
| Login | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Register staff | ✓ | ✓ (scope) | — | — | — | — |
| Manage users | ✓ | — | — | — | — | — |
| Audit logs | ✓ | — | — | — | — | — |
| Loan products (read) | ✓ | — | ✓ | — | — | — |
| Loan products (write) | ✓ | — | — | — | — | — |
| Borrowers (read) | ✓ | ✓ | ✓ | ✓ | — | — |
| Borrowers (write) | ✓ | — | ✓ | ✓ | — | — |
| KYC upload | ✓ | — | ✓ | ✓ | — | — |
| KYC verify | ✓ | — | ✓ | ✗ | — | — |
| Credit assessments | ✓ | ✓ (read) | ✓ | — | — | — |
| Centres / Groups | ✓ | ✓ | — | ✓ | — | — |
| Meetings (read) | ✓ | ✓ | — | ✓ | — | — |
| Meetings (write) | ✓ | — | — | ✓ | — | — |
| Loan applications | ✓ | ✓ (read) | ✓ | ✓ | — | ✓ (own) |
| Sanction letters | ✓ | ✓ (read) | ✓ | — | — | ✓ (own) |
| Loan accounts | ✓ | ✓ (read) | ✓ | ✓ (own) | ✓ | ✓ (own) |
| Collections (write) | ✓ | — | — | ✓ | ✓ | — |
| Collections (read) | ✓ | ✓ | — | ✓ | ✓ | ✓ (own) |
| Delinquency | ✓ | ✓ | — | — | ✓ | — |
| Portfolio reports | ✓ | ✓ | — | — | — | — |
| Send notifications | ✓ | — | — | — | — | — |
| View notifications | ✓ | — | — | — | — | ✓ (own) |

---

## 18. Loan Application State Machine

Valid transitions are enforced in `LoanApplicationServiceImpl.validateStatusTransition()` using a `switch` expression. Any attempt to skip a step or move backward throws `BadRequestException`.

```
         Field Officer / Credit Officer / Admin
                         │
                         ▼
                  ┌────────────┐
                  │   DRAFT    │  ← Always the initial state on creation
                  └─────┬──────┘
                        │  PATCH /{id}/submit
                        │  (FIELD, CREDIT, BORROWER, ADMIN)
                        ▼
               ┌──────────────────┐
               │    SUBMITTED     │
               └────────┬─────────┘
                        │  PATCH /{id}/status → UNDER_REVIEW
                        │  (CREDIT, ADMIN)
                        ▼
              ┌────────────────────┐
              │    UNDER_REVIEW    │
              └──────────┬─────────┘
                         │
               ┌─────────┴──────────┐
               │                    │
               ▼                    ▼
       ┌──────────────┐    ┌──────────────┐
       │   APPROVED   │    │   REJECTED   │
       └──────┬───────┘    └──────────────┘
              │  POST /api/loan-accounts/disburse
              │  (internally sets DISBURSED)
              ▼
       ┌──────────────┐
       │  DISBURSED   │
       └──────────────┘
```

**Invalid transition example:** `SUBMITTED → APPROVED` throws `BadRequestException("Invalid status transition from SUBMITTED to APPROVED")` — the UNDER_REVIEW step cannot be skipped.

---

## 19. EMI Calculation Formulas

Both formulas are implemented in `LoanDisbursementServiceImpl` using `BigDecimal` with `RoundingMode.HALF_UP` throughout.

### Flat Interest

The total interest is fixed at the outset; each installment carries an equal share.

```
Total Interest = Principal × Rate% × Tenure / 1200
EMI            = (Principal + Total Interest) / Tenure

Per installment:
  principalDue = Principal / Tenure
  interestDue  = Total Interest / Tenure
  totalDue     = principalDue + interestDue
```

### Reducing Balance

Interest is calculated on the remaining principal each month, so the interest component decreases over time while the principal component increases.

```
Monthly Rate r = Rate% / 1200
EMI            = P × r × (1 + r)^N  /  ((1 + r)^N − 1)
Total Interest = EMI × N − P

Per installment i:
  interestDue   = remainingPrincipal × r
  principalDue  = EMI − interestDue
  remainingPrincipal -= principalDue
```

**Last installment rounding correction:** The final installment always sets `principalDue = remainingPrincipal` (the exact remaining balance), ensuring `outstandingPrincipal` reaches exactly zero without BigDecimal drift. All N schedule rows are saved in a single `scheduleRepository.saveAll(schedules)` call within the `@Transactional` disburse method.

---

## 20. Collection Payment State Machine

Implemented in `CollectionServiceImpl.recordCollection()`. The method is `@Transactional` — all writes (schedule update, account update, collection record insert) are atomic.

```
POST /api/collections
         │
         ▼
  ┌──────────────────────────┐
  │   Load LoanAccount       │ ──→ 404 if not found
  │   Validate not CLOSED    │ ──→ 400 if CLOSED
  │   Validate amount > 0    │ ──→ 400 if ≤ 0
  └──────────┬───────────────┘
             │
      scheduleID provided?
             │
    YES ─────┴─────────── NO
    │                      │
    ▼                      ▼
Load Schedule          Skip schedule
Compute                update;
remainingDue           CollStatus =
    │                  RECEIVED
    ├── collected >= remaining ──────────────────────────────────┐
    │     schedule.status    = PAID                              │
    │     schedule.amountPaid = totalDue                         │
    │     schedule.paidDate  = today                             │
    │     CollStatus = RECEIVED  (or EXCESS if over-paid)        │
    │                                                            │
    └── collected < remaining ──────────────────────────────────┐│
          schedule.amountPaid += collected  (cumulative)         ││
          schedule.status      = PARTIAL                         ││
          CollStatus           = PARTIAL                         ││
                                                                 ││
         ◄───────────────────────────────────────────────────────┘│
         ◄────────────────────────────────────────────────────────┘
             │
             ▼
  account.outstandingPrincipal = max(0, outstanding − collected)
             │
    outstandingPrincipal == 0?
             │
     YES ────┴──── NO
      │              │
      ▼              ▼
  account.status   (remains
  = CLOSED          ACTIVE)
             │
             ▼
  Save CollectionRecord(collectionStatus)
```

---

## 21. Default Credentials & Data Seeding

On every application startup, `DataSeeder.run()` seeds the following account if it does not already exist:

| Role | Email | Password | Branch ID |
|------|-------|----------|-----------|
| ADMIN | `admin@microlend.com` | `admin123` | 1 |

**Creating additional staff accounts:**

Log in as Admin and call `POST /api/auth/register` with a valid Admin JWT:

```bash
# 1. Get Admin JWT
curl -s -X POST http://localhost:8082/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@microlend.com","password":"admin123"}' \
  | jq -r '.data.token'

# 2. Register a Credit Officer
curl -X POST http://localhost:8082/api/auth/register \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "name":     "Credit Officer One",
    "role":     "CREDIT_OFFICER",
    "email":    "credit@microlend.com",
    "password": "credit123",
    "branchID": 1
  }'
```

**Borrower accounts** are created automatically. When a Field Officer calls `POST /api/borrowers`, the system creates a linked `User` record with `role=BORROWER` using the email and password provided in `BorrowerRequest`. The borrower can then log in at `/api/auth/login` to access their self-service portal.

---

## 22. Test Coverage

The project contains 12 test classes using **JUnit 5** and **Mockito**. All service-layer tests use `@ExtendWith(MockitoExtension.class)` with `@Mock` repositories and `@InjectMocks` service implementations — no database is required and tests run in milliseconds.

The single exception is `MicroLendApplicationTests`, which uses an H2 in-memory database to verify the Spring ApplicationContext loads successfully and `DataSeeder` executes without errors.

**Run all tests:**
```bash
cd backend
mvn test
```

| Test Class | Test Count | Coverage Focus |
|-----------|-----------|----------------|
| `MicroLendApplicationTests` | 2 | Spring context loads; DataSeeder runs without errors |
| `AuditLogServiceTest` | 5 | `log()` creates correct entry; `getAllLogs()` returns full list |
| `AuthServiceTest` | 10 | Login returns JWT; duplicate email rejected; Branch Manager scope enforcement |
| `BorrowerServiceTest` | 13 | Registration with User creation; national ID dedup; null-safe update; delete cascades User |
| `BorrowerKYCServiceTest` | 9 | Upload sets PENDING; verify sets VERIFIED with verifiedByID; reject flow; getByBorrower |
| `CentreServiceTest` | 6 | Create; update fields; getAll; getById throws 404 |
| `CollectionServiceTest` | 17 | Full payment → PAID; partial → PARTIAL + cumulative amountPaid; excess → EXCESS; auto-close at zero; zero amount → 400; closed account → 400 |
| `DelinquencyServiceTest` | 9 | Create case; update DPD and PAR bucket; getByStatus; getByOfficer; 404 on missing |
| `LoanApplicationServiceTest` | 13 | All valid state transitions; all invalid transitions → 400; getByBorrower; getByStatus |
| `LoanProductServiceTest` | 10 | Create; update fields; discontinue sets DISCONTINUED; getById 404 |
| `NotificationServiceTest` | 7 | Send → UNREAD; markRead → READ; dismiss → DISMISSED; getUnreadByUser; 404 on missing |
| `SanctionLetterServiceTest` | 7 | Issue on APPROVED; issue on non-APPROVED → 400; accept; accept non-ISSUED → 400; getByApplicationId 404 |

---

## 23. Quick Start Guide

### Prerequisites

- Java 17 or later
- Apache Maven 3.8 or later
- MySQL 8.0 running on `localhost:3306`

### Steps

**1. Navigate to the backend directory:**
```bash
cd microlend/backend
```

**2. Configure database credentials** (if different from defaults):
```properties
# src/main/resources/application.properties
spring.datasource.username=your_mysql_user
spring.datasource.password=your_mysql_password
```

**3. Build and run:**
```bash
mvn clean install -DskipTests
mvn spring-boot:run
```

The MySQL database `microlend` is auto-created by the JDBC URL. Hibernate auto-generates all 17 tables on first run (`ddl-auto=update`). `DataSeeder` seeds the Admin account.

**4. Verify the application is running:**
```
Tomcat started on port 8082
Application started: MicroLend
```

**5. Authenticate and get a JWT:**
```bash
curl -X POST http://localhost:8082/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@microlend.com","password":"admin123"}'
```

Response:
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiJ9...",
    "type": "Bearer",
    "userID": 1,
    "name": "Admin User",
    "email": "admin@microlend.com",
    "role": "ADMIN",
    "branchID": 1
  }
}
```

**6. Use the token in subsequent requests:**
```bash
curl -H "Authorization: Bearer <token>" \
     http://localhost:8082/api/admin/users
```

**7. Explore via Swagger UI:**

Open `http://localhost:8082/swagger-ui.html` in a browser.  
Click **Authorize** → paste `Bearer <token>` → click **Authorize**.  
All 80 endpoints are now testable directly from the browser.

**8. Trigger the delinquency engine manually (for testing):**
```bash
curl -X POST http://localhost:8082/api/delinquency/trigger \
     -H "Authorization: Bearer <admin-token>"
```

---

*MicroLend Backend Technical Documentation — Spring Boot 3.2 · Java 17 · com.microlend*
