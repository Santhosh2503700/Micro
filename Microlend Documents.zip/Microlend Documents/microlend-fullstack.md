# MicroLend — Full-Stack Documentation

**NBFC Microfinance Loan Management System — Complete Fullstack**

> Backend: Spring Boot 3.2 · Java 17 · MySQL 8 · JWT · Port 8082  
> Frontend: React 18 · Axios · React Router v6 · Recharts · Port 3000

---

## Table of Contents

1. [System Overview](#1-system-overview)
2. [Quick Start](#2-quick-start)
3. [Project Structure](#3-project-structure)
4. [Module 2.1 — Identity & Access Management](#4-module-21--identity--access-management)
5. [Module 2.2 — Borrower Onboarding & KYC](#5-module-22--borrower-onboarding--kyc)
6. [Module 2.3 — Group & Centre Management](#6-module-23--group--centre-management)
7. [Module 2.4 — Loan Origination & Approval](#7-module-24--loan-origination--approval)
8. [Module 2.5 — Loan Disbursement & Accounts](#8-module-25--loan-disbursement--accounts)
9. [Module 2.6 — Collections & Delinquency](#9-module-26--collections--delinquency)
10. [Module 2.7 — Portfolio Analytics & Reporting](#10-module-27--portfolio-analytics--reporting)
11. [Module 2.8 — Notifications & Alerts](#11-module-28--notifications--alerts)
12. [API Reference](#12-api-reference)
13. [Default Credentials](#13-default-credentials)

---

## 1. System Overview

MicroLend is a complete NBFC microfinance loan management system. It digitises the entire micro-loan lifecycle:

```
Borrower Registration → KYC Verification → Credit Assessment → Loan Approval
→ Sanction Letter → Disbursement → Weekly EMI Collection → Delinquency Detection → Reporting
```

### Architecture

```
React 18 (port 3000)
   ↓  Axios + JWT Bearer header
Spring Boot 3.2 (port 8082)
   ↓  JPA/Hibernate
MySQL 8 (port 3306 — database: microlend)
```

### Role System

| Role | Frontend Home | Backend Authority |
|------|--------------|-------------------|
| ADMIN | /admin | Full system access |
| BRANCH_MANAGER | /branch | Branch-scoped staff + portfolio |
| CREDIT_OFFICER | /credit | KYC verify + assess + approve + disburse |
| FIELD_OFFICER | /field | Register borrowers + collect EMIs |
| COLLECTIONS_OFFICER | /collections | Delinquency case recovery |
| BORROWER | /borrower | Own loans + schedule + notifications |

---

## 2. Quick Start

### Backend

```bash
cd backend
# Configure MySQL in application.properties if needed
mvn clean install -DskipTests
mvn spring-boot:run
# Runs on http://localhost:8082
# Swagger UI: http://localhost:8082/swagger-ui.html
# Auto-creates database schema and seeds admin account
```

### Frontend

```bash
cd frontend
npm install
npm start
# Opens http://localhost:3000
```

### Default Admin Login

```
Email:    admin@microlend.com
Password: admin123
```

---

## 3. Project Structure

### Backend (151 Java files)

```
backend/src/main/java/com/microlend/
├── MicroLendApplication.java        @SpringBootApplication @EnableScheduling
├── config/                          SecurityConfig WebConfig SwaggerConfig DataSeeder
├── security/                        JwtUtil JwtAuthFilter CustomUserDetailsService
├── exception/                       GlobalExceptionHandler BadRequestException ResourceNotFoundException
├── dto/request/  (15 files)         Input DTOs with @Valid
├── dto/response/ (2 files)          ApiResponse<T> AuthResponse
├── enums/        (25 files)         All domain enumerations @Enumerated(STRING)
├── entity/       (17 files)         JPA entities = MySQL tables
├── repository/   (17 files)         JpaRepository + custom @Query
├── service/      (17 interfaces)    Pure Java interfaces
├── service/impl/ (17 classes)       @Service implementations
├── controller/   (17 classes)       @RestController endpoints
└── scheduler/                       DelinquencyScheduler @Scheduled(cron="0 30 0 * * *")
```

### Frontend (39 JS files)

```
frontend/src/
├── index.js                         ReactDOM.createRoot() entry
├── App.js                           27 routes + Guard + role routing
├── utils.js                         useApi + Badge + Modal + DataTable + Field + fmt$
├── api/
│   ├── client.js                    Axios + JWT interceptor + 401 handler
│   └── index.js                     50+ API functions
├── context/AuthContext.js           login/logout + localStorage JWT
├── components/Layout.js             Collapsible sidebar + role nav
└── pages/
    ├── Login.js
    ├── admin/     (5 pages)
    ├── field/     (8 pages)
    ├── credit/    (7 pages)
    ├── branch/    (4 pages)
    ├── collections/ (3 pages)
    └── borrower/  (4 pages)
```

---

## 4. Module 2.1 — Identity & Access Management

### Backend Files
- `config/SecurityConfig.java` — JWT filter chain, route-level RBAC, @EnableMethodSecurity
- `config/DataSeeder.java` — Seeds admin@microlend.com on startup
- `config/WebConfig.java` — Global CORS allowedOrigins("*")
- `config/SwaggerConfig.java` — OpenAPI 3 with JWT bearer auth
- `security/JwtUtil.java` — HS256 token generation/validation (jjwt 0.11.5)
- `security/JwtAuthFilter.java` — OncePerRequestFilter, Bearer extraction
- `security/CustomUserDetailsService.java` — loadUserByUsername(email)
- `entity/User.java` — Implements UserDetails, email as username
- `entity/AuditLog.java` — Immutable event log
- `service/impl/AuthServiceImpl.java` — Branch Manager scope enforcement
- `controller/AuthController.java` — POST /api/auth/login (public), POST /api/auth/register
- `controller/UserController.java` — CRUD /api/admin/users
- `controller/AuditLogController.java` — GET /api/admin/audit-logs

### Frontend Files
- `pages/Login.js` — Public login form
- `pages/admin/Dashboard.js` — Stats + recent audit logs
- `pages/admin/Users.js` — Register/manage staff
- `pages/admin/AuditLogs.js` — Read-only audit trail
- `context/AuthContext.js` — JWT storage + role routing
- `components/Layout.js` — Role-specific sidebar

### Database Tables
| Table | Key Columns |
|-------|-------------|
| `users` | userID, email(UNIQUE), password(BCrypt), role, branchID, status |
| `audit_logs` | auditID, userID(0=SYSTEM), action, module, timestamp |

### How It Works
1. `POST /api/auth/login` → AuthServiceImpl validates credentials → JwtUtil.generateToken() → 24h HS256 JWT
2. Frontend stores JWT in localStorage as `ml_token`
3. Axios interceptor attaches `Authorization: Bearer <token>` to every request
4. JwtAuthFilter validates on every request, sets SecurityContextHolder
5. @PreAuthorize on each controller method checks the role
6. Branch Manager registers staff: scope enforced — only FIELD/CREDIT/COLLECTIONS roles, own branch only

---

## 5. Module 2.2 — Borrower Onboarding & KYC

### Backend Files
- `entity/Borrower.java` — @OneToOne User, nationalIDNumber UNIQUE, email UNIQUE
- `entity/BorrowerKYC.java` — borrowerID FK, documentRef, verifiedByID, status=PENDING
- `service/impl/BorrowerServiceImpl.java` — nationalID dedup + auto-creates User(BORROWER)
- `service/impl/BorrowerKYCServiceImpl.java` — create=PENDING, updateStatus sets verifiedByID
- `controller/BorrowerController.java` — CRUD /api/borrowers
- `controller/KYCController.java` — POST /api/kyc (FIELD OK), PATCH /api/kyc/{id}/verify (CREDIT only)

### Frontend Files
- `pages/field/Borrowers.js` — Register with email+password (auto-creates User)
- `pages/field/KYCUpload.js` — Upload docs (amber warning: cannot verify)
- `pages/credit/KYCVerify.js` — Verify/Reject (CREDIT_OFFICER only)

### Database Tables
| Table | Key Columns |
|-------|-------------|
| `borrowers` | borrowerID, name, email(UNIQUE), nationalIDNumber(UNIQUE), user_id(FK→users), status |
| `borrower_kyc` | kycID, borrowerID(FK), documentType, documentRef, verifiedByID(FK), status |

### Maker-Checker Security
- FIELD uploads: `POST /api/kyc` — allowed
- FIELD verifies: `PATCH /api/kyc/{id}/verify` — **403 Forbidden** (two barriers: SecurityConfig route rule + @PreAuthorize)
- Frontend: Guard prevents navigation to /credit/kyc for FIELD_OFFICER

---

## 6. Module 2.3 — Group & Centre Management

### Backend Files
- `entity/Centre.java` — centreName, branchID, fieldOfficerID, meetingDay, meetingTime
- `entity/BorrowerGroup.java` — groupName, centreID, jointLiabilityEnabled, memberCount
- `entity/CentreMeeting.java` — centreID, meetingDate, attendanceCount, collectionAmount
- `controller/CentreController.java` — CRUD /api/centres
- `controller/BorrowerGroupController.java` — CRUD /api/groups + /centre/{id}
- `controller/CentreMeetingController.java` — CRUD /api/meetings + /centre/{id}

### Frontend Files
- `pages/field/Centres.js` — Create centres with meetingDay + meetingTime
- `pages/field/Groups.js` — Create JLG groups with jointLiabilityEnabled
- `pages/field/Meetings.js` — Schedule meetings + record attendance/collections

### Database Tables
| Table | Key Columns |
|-------|-------------|
| `centres` | centreID, centreName, branchID, fieldOfficerID, meetingDay, meetingTime, status |
| `borrower_groups` | groupID, groupName, centreID(FK), jointLiabilityEnabled(TINYINT), memberCount |
| `centre_meetings` | meetingID, centreID(FK), meetingDate, attendanceCount, collectionAmount, status |

---

## 7. Module 2.4 — Loan Origination & Approval

### Backend Files
- `entity/LoanProduct.java` — interestType FLAT or REDUCING
- `entity/LoanApplication.java` — 6-state machine: DRAFT→SUBMITTED→UNDER_REVIEW→APPROVED/REJECTED→DISBURSED
- `entity/CreditAssessment.java` — internalCreditScore, debtBurdenRatio, recommendation
- `entity/SanctionLetter.java` — applicationID UNIQUE, acceptedByBorrower, status
- `service/impl/LoanApplicationServiceImpl.java` — validateStatusTransition() switch expression
- `service/impl/SanctionLetterServiceImpl.java` — issue() validates APPROVED, accept() validates ISSUED

### Frontend Files
- `pages/admin/Products.js` — CRUD + discontinue
- `pages/field/Applications.js` — Create DRAFT + Submit button
- `pages/credit/Applications.js` — State machine UI: Review/Approve/Reject buttons per status
- `pages/credit/Assessments.js` — Credit score + DBR + recommendation
- `pages/credit/Sanctions.js` — Issue on APPROVED + Accept button

### Database Tables
| Table | Key Columns |
|-------|-------------|
| `loan_products` | productID, productName, interestType(FLAT/REDUCING), interestRatePercent, tenureMonths, status |
| `loan_applications` | applicationID, borrowerID, loanProductID, requestedAmount, status(6-state) |
| `credit_assessments` | assessmentID, borrowerID, internalCreditScore, debtBurdenRatio, recommendation |
| `sanction_letters` | sanctionID, applicationID(UNIQUE), sanctionedAmount, emiAmount, acceptedByBorrower, status |

---

## 8. Module 2.5 — Loan Disbursement & Accounts

### Backend Files
- `entity/LoanAccount.java` — outstandingPrincipal, dpd(nightly), status
- `entity/RepaymentSchedule.java` — installmentNumber, dueDate, amountPaid(cumulative), status
- `service/impl/LoanDisbursementServiceImpl.java` — @Transactional: FLAT/REDUCING EMI + saveAll(schedules)
- `repository/RepaymentScheduleRepository.java` — findOverdueInstallments(@Query)

### Frontend Files
- `pages/credit/Disbursements.js` — Select APPROVED app + disburse
- `pages/credit/Accounts.js` — View accounts + inline schedule
- `pages/borrower/Portal.js` — Borrower home with active loans
- `pages/borrower/MyLoans.js` — All loan accounts
- `pages/borrower/Schedule.js` — Full schedule: PAID=green, PARTIAL=amber, OVERDUE=red, amountPaid shown

### Database Tables
| Table | Key Columns |
|-------|-------------|
| `loan_accounts` | loanAccountID, disbursedAmount, outstandingPrincipal, dpd, status(ACTIVE/CLOSED/NPA) |
| `repayment_schedules` | scheduleID, loanAccountID(FK), dueDate, totalDue, amountPaid(cumulative), paidDate, status |

### EMI Formulas
- **FLAT:** `totalInterest = P × R × T / 1200`, `EMI = (P + totalInterest) / T`
- **REDUCING:** `r = R/1200`, `EMI = P × r × (1+r)^N / ((1+r)^N - 1)`

---

## 9. Module 2.6 — Collections & Delinquency

### Backend Files
- `entity/CollectionRecord.java` — collectedAmount, mode, scheduleID(optional), status
- `entity/DelinquencyCase.java` — loanAccountID, dpd, parBucket, openedDate, action, status
- `service/impl/CollectionServiceImpl.java` — @Transactional 3-branch: FULL/PARTIAL/EXCESS
- `scheduler/DelinquencyScheduler.java` — @Scheduled(cron="0 30 0 * * *") nightly engine

### Frontend Files
- `pages/field/Collections.js` — Record payments with FULL/PARTIAL/EXCESS info
- `pages/collections/Cases.js` — Update case action/status
- `pages/collections/RecordPayment.js` — Recovery payments
- `pages/branch/Delinquency.js` — Monitor cases + Trigger Engine button

### Database Tables
| Table | Key Columns |
|-------|-------------|
| `collection_records` | collectionID, loanAccountID(FK), scheduleID(FK?), collectedAmount, mode, status(RECEIVED/PARTIAL/EXCESS) |
| `delinquency_cases` | delinquencyID, loanAccountID(FK), dpd, parBucket(PAR30/60/90/180), openedDate, action, status |

### Collection State Machine
- `collected >= remaining` → PAID, CollectionStatus=RECEIVED
- `collected < remaining` → amountPaid += collected (cumulative), PARTIAL
- `collected > remaining` → PAID, CollectionStatus=EXCESS
- `outstandingPrincipal = 0` → LoanAccount.status = CLOSED

### Nightly Scheduler
- Fires at 00:30 AM: `@Scheduled(cron="0 30 0 * * *")`
- Queries `findOverdueInstallments(today)` WHERE dueDate < today AND status IN (PENDING, PARTIAL)
- Calculates DPD = `ChronoUnit.DAYS.between(dueDate, today)`
- Marks NPA at DPD >= 90 (RBI threshold)
- PAR buckets: PAR30=30-59d, PAR60=60-89d, PAR90=90-179d, PAR180=180+d

---

## 10. Module 2.7 — Portfolio Analytics & Reporting

### Backend Files
- `entity/PortfolioReport.java` — scope, activeLoanCount, totalOutstanding, npaPercent
- `service/impl/PortfolioReportServiceImpl.java` — aggregates: count ACTIVE, sum outstanding, npaPercent
- `controller/PortfolioReportController.java` — POST /api/reports/generate, GET /api/reports

### Frontend Files
- `pages/branch/Dashboard.js` — Generate report + StatCards + Recharts BarChart + history
- `pages/branch/Accounts.js` — All loan accounts overview

### Database Tables
| Table | Key Columns |
|-------|-------------|
| `portfolio_reports` | reportID, scope, activeLoanCount, totalOutstanding, disbursementValue, npaPercent, generatedDate |

---

## 11. Module 2.8 — Notifications & Alerts

### Backend Files
- `entity/Notification.java` — userID, message(500), category, status=UNREAD, createdDate
- `service/impl/NotificationServiceImpl.java` — send=UNREAD, markRead=READ, dismiss=DISMISSED
- `controller/NotificationController.java` — POST /send, GET /user/{id}, PATCH /read, PATCH /dismiss

### Frontend Files
- `pages/admin/Notifications.js` — Send notification + view all
- `pages/borrower/Notifications.js` — Inbox: UNREAD=blue, Read/Dismiss buttons

### Database Tables
| Table | Key Columns |
|-------|-------------|
| `notifications` | notificationID, userID(FK), message(500 chars), category, status(UNREAD→READ→DISMISSED), createdDate |

---

## 12. API Reference

| # | Method | Endpoint | Min Role |
|---|--------|----------|----------|
| 1 | POST | /api/auth/login | PUBLIC |
| 2 | POST | /api/auth/register | ADMIN/BM |
| 3-7 | GET/PATCH/DELETE | /api/admin/users/** | ADMIN |
| 8 | GET | /api/admin/audit-logs | ADMIN |
| 9-13 | POST/GET/PUT/PATCH | /api/loan-products/** | ADMIN |
| 14-19 | POST/GET/PUT/DELETE | /api/borrowers/** | ADMIN/CREDIT/FIELD |
| 20-24 | POST/GET/PATCH | /api/kyc/** | CREDIT/FIELD |
| 25-28 | POST/GET/PUT | /api/centres/** | FIELD/BRANCH |
| 29-33 | POST/GET/PUT | /api/groups/** | FIELD/BRANCH |
| 34-38 | POST/GET/PUT | /api/meetings/** | FIELD/BRANCH |
| 39-45 | POST/GET/PATCH | /api/loan-applications/** | ADMIN/CREDIT/FIELD |
| 46-49 | POST/GET/PUT | /api/credit-assessments/** | CREDIT |
| 50-54 | POST/GET/PATCH | /api/sanction-letters/** | CREDIT |
| 55-59 | POST/GET | /api/loan-accounts/** | CREDIT/BORROWER |
| 60-63 | POST/GET | /api/collections/** | FIELD/COLLECTIONS |
| 64-71 | POST/GET/PUT | /api/delinquency/** | COLLECTIONS/BRANCH |
| 72-74 | POST/GET | /api/reports/** | ADMIN/BRANCH |
| 75-80 | POST/GET/PATCH | /api/notifications/** | ADMIN/ALL |

**Total: 80 endpoints**

---

## 13. Default Credentials

| Role | Email | Password | Notes |
|------|-------|----------|-------|
| ADMIN | admin@microlend.com | admin123 | Seeded on startup by DataSeeder |
| Others | — | — | Register via Admin → /admin/users → Register Staff |
| BORROWER | — | — | Auto-created when Field Officer registers a borrower |

---

*MicroLend Fullstack Documentation — Spring Boot 3.2 · React 18 · MySQL 8 · com.microlend*
